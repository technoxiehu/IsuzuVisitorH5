package com.netease.qiye.qiyeopenplatform.common.dto.open.maillist;

import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class MailListPageReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "分页数")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小,默认最大都为50")
    @Range(min = 1, max = 50, message = "分页大小 不能超过50，亦不小于1")
    private Integer pageSize = 50;
}
