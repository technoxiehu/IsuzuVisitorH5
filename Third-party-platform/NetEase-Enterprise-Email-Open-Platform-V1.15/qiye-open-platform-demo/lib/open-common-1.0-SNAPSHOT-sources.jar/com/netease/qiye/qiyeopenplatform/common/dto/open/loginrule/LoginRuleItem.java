package com.netease.qiye.qiyeopenplatform.common.dto.open.loginrule;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoginRuleItem {

    @ApiModelProperty(value = "是否允许ip端（该规则）内登录,0-允许登录 1-不允许登录")
    private Integer action;

    @ApiModelProperty(value = "ip段")
    private String ip;

    @ApiModelProperty(value = "排序值")
    private Integer rank;
}
