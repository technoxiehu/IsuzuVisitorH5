package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @description: 权限字典请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class DictionaryInfoReq {

    @NotBlank(message = "权限名称 不能为空")
    @ApiModelProperty(value = "权限名称", required = true)
    private String permissionName;

    @NotBlank(message = "接口url 不能为空")
    @ApiModelProperty(value = "接口url", example = "/api/open/domain", required = true)
    private String url;

}
