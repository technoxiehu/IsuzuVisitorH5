package com.netease.qiye.qiyeopenplatform.common.dto.login;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/8
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AppLogoutResp {

    @ApiModelProperty(value = "调用凭证")
    private String accessToken;

    @ApiModelProperty(value = "更新凭证")
    private String refreshToken;

    @JsonFormat(pattern = DateUtils.DATETIME_COMMON, timezone = "gmt+8")
    @ApiModelProperty(value = "调用凭证有效期截止")
    private Date accessTokenExpiredTime;

    @JsonFormat(pattern = DateUtils.DATETIME_COMMON, timezone = "gmt+8")
    @ApiModelProperty(value = "更新凭证有效期截止")
    private Date refreshTokenExpiredTime;

}
