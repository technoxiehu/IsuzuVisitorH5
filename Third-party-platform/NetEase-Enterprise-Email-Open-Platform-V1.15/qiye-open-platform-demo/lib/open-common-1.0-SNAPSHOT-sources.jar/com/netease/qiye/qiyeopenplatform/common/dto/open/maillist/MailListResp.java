package com.netease.qiye.qiyeopenplatform.common.dto.open.maillist;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailListResp {

    @ApiModelProperty(value = "邮件列表名称，邮箱格式的前缀")
    @JsonAlias("account_name")
    private String accountName;

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "邮件列表名称")
    @JsonAlias("nickname")
    private String name;

    @ApiModelProperty(value = "通讯录中是否可见,限定值：1 可见/ 0 不可见")
    @JsonAlias("addr_visible")
    private Integer visibleInAddr = 1;

    @ApiModelProperty(value = "邮件列表成员(邮箱)")
    @JsonAlias("forwardlist")
    private List<String> members;

    @ApiModelProperty(value = "群组列表使用者类型,限定值： 0 允许所有人/ 2 允许列表中的用户和授权用户/ 3 只允许授权用户/ 4 允许域内所有用户")
    @JsonAlias("maillist_right")
    private Integer mailListUserType;

    @ApiModelProperty(value = "授权使用邮件列表成员（邮箱）,选填，mailListUserType为2或3时有效\t用英文逗号 , 隔开的帐号列表 例如\nadmin@test.com,test2@test.com")
    @JsonAlias("safelist")
    private String authMembers;

    @ApiModelProperty(value = "授邮件列表成员（部门）,用英文逗号 , 隔开的部门unitid 例如123,123456")
    @JsonAlias("unitlist")
    private List<String> memberUnits;
}
