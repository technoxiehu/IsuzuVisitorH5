package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountResp;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AddressRevisionDataResp {

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "版本号")
    private Long revision;

    @ApiModelProperty(value = "操作类型")
    private String op;

    @ApiModelProperty(value = "企业OpenId")
    @JsonAlias("org_openid")
    private String orgOpenId;

    private AccountResp account;
}
