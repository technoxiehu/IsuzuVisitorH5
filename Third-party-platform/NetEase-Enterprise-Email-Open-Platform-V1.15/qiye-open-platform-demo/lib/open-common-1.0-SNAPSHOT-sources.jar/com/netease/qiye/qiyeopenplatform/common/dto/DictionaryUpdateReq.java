package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: 权限字典更新请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class DictionaryUpdateReq {

    @ApiModelProperty(value = "权限字典ID", required = true)
    private Long id;
    @ApiModelProperty(value = "权限字典名称")
    private String permissionName;
    @ApiModelProperty(value = "接口url", example = "/api/open/domain")
    private String url;
    @ApiModelProperty(value = "用于url分级，即存在多少个分隔符", example = "1")
    private Integer level;
    @ApiModelProperty(value = "状态 0正常 1冻结")
    private Integer status;
}
