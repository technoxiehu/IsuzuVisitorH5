package com.netease.qiye.qiyeopenplatform.sdk.exception;

/**
 * 传输异常，可以捕获并重试
 *
 * @author caixianyong
 * @createtime 2021/10/22
 */
public class OpenApiIOException extends RuntimeException {

    private String msg;

    public OpenApiIOException(String msg) {
        super(msg);
        this.msg = msg;
    }
}