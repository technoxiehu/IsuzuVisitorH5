package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/26
 */
@Data
public class MailFlag {

    private boolean read;

    private boolean popRead;

    private boolean scheduleDelivery;

    private boolean attached;

    private boolean inlineAttached;

    private boolean linkAttached;

    private boolean signed;

    private boolean encrypted;

    private boolean replied;

    private boolean forwarded;

    private boolean draft;

    private boolean voice;

    private boolean fax;

    private boolean flagged;

    private boolean deleted;

    private boolean top;

    private boolean rcptQueued;

    private boolean rcptFailed;

    private boolean rcptSucceed;

    private boolean deferHandle;


}
