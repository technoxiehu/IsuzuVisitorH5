package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AddressAccountItem {

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "邮箱帐号名")
    @JsonAlias("account_name")
    private String accountName;

    @ApiModelProperty(value = "帐号类型,0-邮件列表，2-普通帐号")
    private Integer type;

    @ApiModelProperty(value = "性别：0-男，1-女，2-保密")
    //TODO 性别参数有问题
    private String gender;//性别：0-男，1-女，2-保密

    @ApiModelProperty(value = "工号")
    @JsonAlias("job_no")
    private String jobNumber;//工号

    @ApiModelProperty(value = "姓名")
    @JsonAlias("nickname")
    private String name;//姓名

    @ApiModelProperty(value = "手机")
    private String mobile;//手机

    @ApiModelProperty(value = "部门id")
    @JsonAlias("unit_id")
    private String unitId;

    @ApiModelProperty(value = "备注")
    private String remark;// 备注

    @ApiModelProperty(value = "电子邮箱地址")
    private String email;
}
