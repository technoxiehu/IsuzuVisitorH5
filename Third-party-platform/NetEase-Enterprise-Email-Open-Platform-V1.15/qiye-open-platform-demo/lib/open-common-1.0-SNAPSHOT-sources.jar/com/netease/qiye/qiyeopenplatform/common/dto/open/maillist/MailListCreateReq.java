package com.netease.qiye.qiyeopenplatform.common.dto.open.maillist;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailListCreateReq implements OpenBaseReq {

    @ApiModelProperty(value = "邮件列表名称，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "邮件列表名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "邮件列表名称", required = true)
    @ServletDispatcherFieldAlias("nickname")
    @NotBlank(message = "邮件列表名称 不能为空")
    private String name;

    @ApiModelProperty(value = "通讯录中是否可见,限定值：1 可见/ 0 不可见")
    @ServletDispatcherFieldAlias("addr_visible")
    private Integer visibleInAddr = 1;

    @ApiModelProperty(required = true, value = "邮件列表成员（邮箱）,用英文逗号 , 隔开的邮件地址列表 例如test1@test.com,test2@test.com，与memberUnits至少存在一个")
    @ServletDispatcherFieldAlias("forwardlist")
//    @NotBlank(message = "邮件列表成员（邮箱） 不能为空")
    private String members;

    @ApiModelProperty(required = true, value = "群组列表使用者类型,限定值： 0 允许所有人/ 2 允许列表中的用户和授权用户/ 3 只允许授权用户/ 4 允许域内所有用户")
    @ServletDispatcherFieldAlias("maillist_right")
    @NotNull(message = "群组列表使用者类型 不能为空")
    private Integer mailListUserType;

    @ApiModelProperty(required = true, value = "授权使用邮件列表的人（邮箱）,选填，mailListUserType为2或3时有效\t用英文逗号 , 隔开的帐号列表 例如\n" +
            "admin@test.com,test2@test.com")
    @ServletDispatcherFieldAlias("safelist")
//    @NotBlank(message = "授权使用邮件列表成员（邮箱） 不能为空")
    private String authMembers;

    @ApiModelProperty(required = true, value = "邮件列表成员（部门）,用英文逗号 , 隔开的部门unitid 例如123,123456，与members至少存在一个")
    @ServletDispatcherFieldAlias("unitlist")
//    @NotBlank(message = "邮件列表成员（部门） 不能为空")
    private String memberUnits;
}
