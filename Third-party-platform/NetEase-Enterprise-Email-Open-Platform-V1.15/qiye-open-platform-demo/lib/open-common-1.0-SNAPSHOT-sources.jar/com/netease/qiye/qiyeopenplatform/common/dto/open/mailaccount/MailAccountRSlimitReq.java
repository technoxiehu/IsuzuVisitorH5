package com.netease.qiye.qiyeopenplatform.common.dto.open.mailaccount;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class MailAccountRSlimitReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "用户账号名 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true, value = "邮件收发限制类型,17-只能发送域内邮件，收信无限制\n" +
            "18-只能接受域内邮件，发信无限制\n" +
            "19-只能收发域内邮件\n" +
            "-1-无限制")
    @ServletDispatcherFieldAlias("rs_limit")
    @NotNull(message = "邮件收发限制类型 不能为空")
    private Integer rsLimitType;

}
