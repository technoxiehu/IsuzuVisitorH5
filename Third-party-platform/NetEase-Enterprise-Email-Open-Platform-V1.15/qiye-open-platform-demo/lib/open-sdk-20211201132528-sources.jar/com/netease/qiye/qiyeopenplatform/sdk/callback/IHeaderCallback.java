package com.netease.qiye.qiyeopenplatform.sdk.callback;

import java.util.Map;

/**
 * @author caixianyong
 * @createtime 2021/10/21
 */
@FunctionalInterface
public interface IHeaderCallback {

    /**
     * 最终请求头处理回调
     * 适用于不影响请求的拓展性参数（请求签名，时间戳，请求版本等）
     *
     * @param params  JSON请求体序列化得到的Map
     * @param headers 全局+动态请求头
     * @return 返回最终请求头
     */
    Map<String, String> apply(Map<String, Object> params, Map<String, String> headers);

}
