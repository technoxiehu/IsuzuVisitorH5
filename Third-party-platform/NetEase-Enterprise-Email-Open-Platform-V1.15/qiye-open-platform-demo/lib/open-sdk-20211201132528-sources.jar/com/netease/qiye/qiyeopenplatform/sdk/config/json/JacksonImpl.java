package com.netease.qiye.qiyeopenplatform.sdk.config.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.netease.qiye.qiyeopenplatform.sdk.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Slf4j
public class JacksonImpl implements IJson {

    // 默认jackson对象
    private static ObjectMapper defaultObjectMapper = new ObjectMapper();

    // 使用特定日期格式的jackson对象
    private static ObjectMapper dateFormatObjectMapper = new ObjectMapper();

    static {
        defaultObjectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        dateFormatObjectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Override
    public String toJsonString(Object o) {
        String res = null;
        try {
            res = defaultObjectMapper.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            log.error(e.getMessage(), e);
        }
        return res;
    }

    @Override
    public <T> T parseObject(String jsonText, Class<T> c) {
        T obj = null;
        if (!CommonUtils.isStringEmpty(jsonText)) {
            try {
                obj = defaultObjectMapper.readValue(jsonText, c);
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
        return obj;
    }

    @Override
    public <T> List<T> parseList(String jsonText, Class<T> c) {
        try {
            return defaultObjectMapper.readValue(jsonText, TypeFactory.defaultInstance()
                    .constructCollectionType(List.class, c));
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException("JSON反序列化出错");
        }
    }
}
