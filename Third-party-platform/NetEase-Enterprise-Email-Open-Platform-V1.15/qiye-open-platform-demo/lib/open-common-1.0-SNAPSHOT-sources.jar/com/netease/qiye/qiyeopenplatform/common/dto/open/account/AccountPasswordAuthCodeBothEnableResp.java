package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/23
 */
@Data
public class AccountPasswordAuthCodeBothEnableResp {

    @JsonAlias("isWebpassAndAuthcodeBothEnabled")
    @ApiModelProperty("是否同时允许 password 和 authcode 方式登录")
    private Boolean bothEnable;

}
