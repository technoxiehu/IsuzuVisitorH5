package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class AccountAliasReq implements OpenBaseReq {


    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "别名", required = true)
    @ServletDispatcherFieldAlias("alias_name")
    @NotBlank(message = "别名 不能为空")
    private String aliasName;

    @ApiModelProperty(value = "域名别名, 删除实现暂不支持该参数")
    @ServletDispatcherFieldAlias("alias_domain")
    private String aliasDomain;

}
