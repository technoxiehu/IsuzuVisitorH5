package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressUpdateReq implements OpenBaseReq {

    @ApiModelProperty(value = "查询返回的addressId", required = true)
    @ServletDispatcherFieldAlias("address_id")
    private Long addressId;

    @ApiModelProperty(value = "域名", required = true)
    private String domain;

    @ApiModelProperty(value = "邮箱地址")
    private String email;

    @ApiModelProperty(value = "名称")
    @ServletDispatcherFieldAlias("nickname")
    private String name;

    @ApiModelProperty(value = "手机号码")
    private String mobile;

    @ApiModelProperty(value = "公司")
    private String company;

    @ApiModelProperty(value = "部门")
    private String department;

    @ApiModelProperty(value = "电话号码")
    private String tel;

    @ApiModelProperty(value = "传真")
    private String fax;

    @ApiModelProperty(value = "地址")
    private String address;

    @ApiModelProperty(value = "生日，unix时间戳")
    private Long birthday;

    @ApiModelProperty(value = "职业")
    private String job;

    @ApiModelProperty(value = "工号")
    @ServletDispatcherFieldAlias("jobnumber")
    private String jobNumber;

    @ApiModelProperty(value = "分组ID，多个使用英文逗号分隔")
    @ServletDispatcherFieldAlias("group_ids")
    private String groupIds;

}
