package com.netease.qiye.qiyeopenplatform.common.dto.open.loginrule;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class LoginRuleReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "IP白名单，x.x.x.x的IP格式或者1.1.1.1-1.1.2.1的格式，空集用空列表{}表示", required = true)
    @NotNull(message = "IP白名单 不能为空")
    private List<String> allowIps;

    @ApiModelProperty(value = "IP黑名单，x.x.x.x的IP格式或者1.1.1.1-1.1.2.1的格式，空集用空列表{}表示", required = true)
    @NotNull(message = "IP黑名单 不能为空")
    private List<String> denyIps;

    @ApiModelProperty(required = true, value = "是否允许规则外登录，0-允许登录 1-不允许登录")
    @NotNull(message = "action 不能为空")
    private Integer action;

    @ApiModelProperty(value = "该域下电子邮件列表", required = true,
            notes = "带域名")
    @NotEmpty(message = "规则约束的电子邮箱数组 不能为空")
    private List<String> accountList;

    @ApiModelProperty(value = "规则Id，用于更新接口", required = true)
    @ServletDispatcherFieldAlias("rule_id")
    private Long ruleId;
}
