package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressItem {

    @ApiModelProperty(value = "公共联系人id")
    @JsonAlias("address_id")
    private Long addressId;

    @ApiModelProperty(value = "邮箱地址")
    private String email;

    @ApiModelProperty(value = "分组")
    private List<PubAddressGroup> groups;

    @ApiModelProperty(value = "姓名")
    @JsonAlias("nickname")
    private String name;

}
