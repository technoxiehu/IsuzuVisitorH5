package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * @description: 应用请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class AppUpdateReq {

    @ApiModelProperty(value = "id", required = true)
    @NotNull(message = "id 不能为空")
    private Long id;

    @ApiModelProperty(value = "应用名称")
    private String appName;

    @ApiModelProperty(value = "状态 0正常 1冻结")
    @Range(min = 0, max = 1, message = "0正常 1冻结")
    private Integer status;
}
