package com.netease.qiye.qiyeopenplatform.common.dto.open.logquery;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 收发信日志查询
 *
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class MailLogQueryResp {

    @ApiModelProperty("发件方")
    private String mailfrom;

    @ApiModelProperty("收件方")
    private String mailto;

    @ApiModelProperty("邮箱主题")
    private String subject;

    @ApiModelProperty("邮件大小")
    @JsonAlias("mailsize")
    private Long mailSize;

    @ApiModelProperty("收发信时间")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    @JsonAlias("sendtime")
    private Date time;

    @ApiModelProperty("发件IP")
    @JsonAlias("sendip")
    private String sendIp;

    @ApiModelProperty("发送接收状态： 发送：1-发送成功，4-发送失败，10-投递中；接收：1-成功接收，2-被隔离（已被成功转移），3-被隔离，0-未知状态")
    private Integer result;


}
