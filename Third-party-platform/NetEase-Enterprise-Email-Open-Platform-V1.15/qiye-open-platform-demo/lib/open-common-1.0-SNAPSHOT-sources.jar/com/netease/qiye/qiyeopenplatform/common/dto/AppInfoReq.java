package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @description: 应用请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class AppInfoReq {

    @ApiModelProperty(value = "应用名称", required = true)
    @NotBlank(message = "应用名称 不能为空")
    private String appName;

    @ApiModelProperty(value = "是否内部应用 0表示第三方应用，1表示企业内部应用", required = true)
    @Range(min = 0, max = 1, message = "是否内部应用 取值有误, 0表示第三方应用，1表示企业内部应用")
    @NotNull(message = "是否内部应用 不能为空")
    private Integer innerApp;

}
