package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @description: token请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/3 10:47
 */
@Data
public class TokenHistoryReq {

    @NotBlank(message = "应用ID 不能为空")
    @ApiModelProperty(value = "应用ID", required = true)
    private String appId;

    @NotBlank(message = "企业OpenID 不能为空")
    @ApiModelProperty(value = "企业OpenID", required = true)
    private String orgOpenId;

}
