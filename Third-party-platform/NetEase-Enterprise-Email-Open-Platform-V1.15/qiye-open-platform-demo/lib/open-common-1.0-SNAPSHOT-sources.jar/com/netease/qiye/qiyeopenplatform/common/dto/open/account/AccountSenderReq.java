package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 指定账户发信人
 *
 * @author caixianyong
 * @createtime 2021/9/10
 * @see AccountSenderReq
 */
@Data
public class AccountSenderReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true, value = "发件人,完整的emai地址，帐号部分必须为主帐号或帐号的别名，域名部分必须为主域名或域别名")
    @NotBlank(message = "发件人 不能为空")
    private String sender;
}
