package com.netease.qiye.qiyeopenplatform.common.dto.open.logquery;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.Date;
import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/11/17
 */
@Data
public class LoginLockedQueryReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀")
    @ServletDispatcherFieldAlias("accounts")
    private List<String> accountNames;

    @ApiModelProperty(value = "日志时间范围起始")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    @ServletDispatcherFieldAlias(value = "start", datePattern = DateUtils.DATETIME_COMMON)
    private Date startTime;

    @ApiModelProperty(value = "日志时间范围截止")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    @ServletDispatcherFieldAlias(value = "end", datePattern = DateUtils.DATETIME_COMMON)
    private Date endTime;

    @ApiModelProperty(value = "分页数，不填默认不分页")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小，默认50")
    @Range(min = 1, max = 1000, message = "分页大小 不能超过1000，亦不小于1")
    private Integer pageSize = 50;

    @ApiModelProperty(value = "可以指定为true来获取尚未解锁的锁定记录(用于解锁)")
    private Boolean locked = false;

}
