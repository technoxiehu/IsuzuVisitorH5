package com.netease.qiye.qiyeopenplatform.sdk.service.open;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public interface IMailBoxService {


}
