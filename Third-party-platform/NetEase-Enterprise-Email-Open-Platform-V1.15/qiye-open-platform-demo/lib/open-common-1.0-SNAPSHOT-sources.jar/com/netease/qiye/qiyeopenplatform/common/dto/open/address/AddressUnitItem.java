package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AddressUnitItem {

    @ApiModelProperty(value = "部门id")
    @JsonAlias("unit_id")
    private String unitId;

    @ApiModelProperty(value = "父部门id")
    @JsonAlias("parent_id")
    private String unitParentId;

    @ApiModelProperty(value = "部门名称")
    @JsonAlias("unit_name")
    private String unitName;

    @ApiModelProperty(value = "是否存在子部门")
    private String hasChild;
}
