package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.dto.open.mailaccount.MailAccountResp;
import com.netease.qiye.qiyeopenplatform.common.util.CommonUtils;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * 遗留，
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountResp {

    @ApiModelProperty(value = "企业openid")
    @JsonAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "帐号openid")
    @JsonAlias("account_openid")
    private String accountOpenId;

    @ApiModelProperty(value = "域名openid")
    @JsonAlias("domain_openid")
    private String domainOpenId;

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "邮箱帐号名")
    @JsonAlias("account_name")
    private String accountName;

    @ApiModelProperty(value = "姓名")
    @JsonAlias("nickname")
    private String name;

    @ApiModelProperty(value = "手机")
    private String mobile;

    @ApiModelProperty(value = "工号")
    @JsonAlias("job_no")
    private String jobNumber;

    @ApiModelProperty(value = "职位")
    private String job;

    @ApiModelProperty(value = "帐号创建时间")
    @JsonAlias("create_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date createTime;

    @ApiModelProperty(value = "帐号类型：-1超级管理员，0-邮件列表，1-别名，2-普通帐号")
    //帐号类型：-1超级管理员，0-邮件列表，1-别名，2-普通帐号
    private int type;

    @ApiModelProperty(value = "所属部门id列表")
    @JsonAlias("unit_list")
    private List<String> unitList;

    @ApiModelProperty(value = "别名列表")
    @JsonAlias("alias_list")
    private List<String> aliasList;//别名列表

    @ApiModelProperty(value = "用于显示的部门id")
    @JsonAlias("unit_id")
    private String unitId;

    @ApiModelProperty(value = "部门名称")
    @JsonAlias("unit_name")
    private String unitName;

    @ApiModelProperty(value = "状态0-正常，1-禁用，2-已删除")
    private int status;//状态0-正常，1-禁用，2-已删除

    @ApiModelProperty(value = "是否在通讯录可见0-不可见，1-可见")
    @JsonAlias("addr_visible")
    private int visibleInAddr;//是否在通讯录可见0-不可见，1-可见

    @ApiModelProperty(value = "是否有自动转发权限 0-否，1-是")
    @JsonAlias("fwd")
    private Integer enableFwd;

    public Integer getEnableFwd() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("fwd");
    }

    @ApiModelProperty(value = "自动转发是否需要手机验证 0-否，1-是")
    @JsonAlias("fwdmauth")
    private Integer fwdMAuth;

    public Integer getFwdMAuth() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("fwdmauth");
    }

    @ApiModelProperty(value = "是否允许通过手机验证码重置密码，0-禁止，1允许")
    @JsonAlias("pass_mobile")
    private Integer enableMobileResetPass;

    public Integer getEnableMobileResetPass() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("pass_mobile");
    }

    @ApiModelProperty(value = "是否允许自助重置密码，0-禁止，1允许")
    @JsonAlias("pass_general")
    private Integer enableCommonResetPass;

    public Integer getEnableCommonResetPass() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("pass_general");
    }

    @ApiModelProperty(value = "是否开启客户端授权码，0-关闭，1-开启")
    @JsonAlias("authcode_status")
    private Integer enableAuth;//授权码状态：0-关闭，1-开启

    @ApiModelProperty(value = "传真")
    private String fax;//传真

    @ApiModelProperty(value = "电话")
    private String tel;//电话

    @ApiModelProperty(value = "性别：0-男，1-女，2-保密")
    private String gender;//性别：0-男，1-女，2-保密

    @ApiModelProperty(value = "是否强制开启二次验证,0 -不强制,1-强制,-1不更改")
    @JsonAlias("secondary_logon")
    private int secondaryLogon;

    @ApiModelProperty(value = "帐号首次登录是否需要修改密码 0-不需要，1-web登录需要，客户端不需要，2-web登录需要且未改密码前客户端不能登录")
    @JsonAlias("passchange_req")
    private Integer passChangeFirstLogin;

    @ApiModelProperty(value = "上一次修改密码时间")
    @JsonAlias("passchange_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date passLastModifyTime;//上一次修改密码时间

    @ApiModelProperty(value = "是否有查看企业通讯录权限 0-没有，1-有")
    @JsonAlias("addr_right")
    private Integer enableAccessAddr;//是否有通讯录使用权限，D0-无，1-有

    @ApiModelProperty(value = "备注")
    private String remark;// 备注

    @ApiModelProperty(value = "是否有网页端登录权限，0-没有，1-有")
    private int web = 1;// web登录权限

    @ApiModelProperty(value = "是否有pop登录权限，0-没有，1-有")
    private int pop = 1;// pop登录权限

    @ApiModelProperty(value = "是否有imap登录权限，0-没有，1-有")
    private int imap = 1;// imap登录权限

    @ApiModelProperty(value = "是否有smtp登录权限，0-没有，1-有")
    private int smtp = 1;// smtp登录权限

    @ApiModelProperty(value = "是否有闪电邮登录权限，0-没有，1-有")
    private int flashmail = 1;// flashmail登录权限

    @ApiModelProperty(value = "是否有马上办登录权限，0-没有，1-有")
    private int yixin = 1;// yixin登录权限

    @ApiModelProperty(value = "是否开启邮箱大师私有协议，0-没有开启，1-开启")
    private int dashi = 1;// 大师私有协议登录权限

    // 是否已激活超大附件,如果bigattach_right设置为1（有权限），那么账号登录webmail的时候就会来通过mailaccount/activeBigAttachment开启这个数据(对应tb_domainmail_account的extendc字段)
    @ApiModelProperty(value = "是否已激活超大附件，0-没有，1-有")
    @JsonAlias("bigattach_status")
    private int bigattachStatus;

    // 账号是否有超大附件的权限，对应管理后台账号新建、编辑页面的云附件权限,1-有，0-无
    @ApiModelProperty(value = "是否有超大附件的权限，0-没有，1-有")
    @JsonAlias("bigattach_right")
    private int bigattachRight;

    @ApiModelProperty(value = "是否禁止主账号登录，0-允许，1-禁止")
    @JsonAlias("main_account_login_forbidden")
    private int mainAccountLoginForbidden; //是否禁止主账号登录:0-允许,1-禁止

    @ApiModelProperty(value = "帐号关联的邮箱列表")
    @JsonAlias("mailaccount_list")
    private List<MailAccountResp> mailAccountList;// 帐号关联的邮箱列表

    @ApiModelProperty(hidden = true)
    private String settings;
}
