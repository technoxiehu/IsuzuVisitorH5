package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class AddressReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀, 用户帐号（传了帐号则会检查用户是否有通讯录权限）")
    @ServletDispatcherFieldAlias("account_name")
    private String accountName;

    @ApiModelProperty(value = "通讯录是否过滤邮件列表，默认false")
    @ServletDispatcherFieldAlias("nomaillist")
    private Boolean excludeMailList = false;

    @ApiModelProperty(value = "通讯录是否过滤公共联系人，默认false")
    @ServletDispatcherFieldAlias("nopub")
    private Boolean excludePubAddress = false;

    @ApiModelProperty(value = "通讯录是否过滤共享？，默认false")
    @ServletDispatcherFieldAlias("noshare")
    private Boolean excludeShare = false;

}
