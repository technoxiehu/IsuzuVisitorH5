package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: 应用授权响应
 * @author: ZhuXiaoShu
 * @date: 2021/9/3 10:29
 */
@Data
public class AppAuthResp {

    @ApiModelProperty(value = "授权ID")
    private Long id;
    @ApiModelProperty(value = "应用ID")
    private String appId;
    @ApiModelProperty(value = "企业ID")
    private String orgOpenId;
    @ApiModelProperty(value = "授权码")
    private String authCode;
    @ApiModelProperty(value = "权限ID集")
    private String permissionIdSet;
    @ApiModelProperty(value = "可访问IP集")
    private String accessIpSet;
    @ApiModelProperty(value = "状态，0 正常 1 冻结")
    private Integer status;
}
