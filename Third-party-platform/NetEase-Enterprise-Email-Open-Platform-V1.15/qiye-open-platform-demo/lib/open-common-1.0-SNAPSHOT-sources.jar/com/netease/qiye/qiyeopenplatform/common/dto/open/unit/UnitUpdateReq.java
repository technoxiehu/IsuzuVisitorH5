package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class UnitUpdateReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名不能为空")
    private String domain;

    @ApiModelProperty(value = "部门id", required = true)
    @ServletDispatcherFieldAlias("unit_id")
    @NotBlank(message = "部门id 不能为空")
    private String unitId;

    @ApiModelProperty(value = "部门名称", required = true)
    @ServletDispatcherFieldAlias("unit_name")
    @NotBlank(message = "部门名称 不能为空")
    private String unitName;

    @ApiModelProperty(value = "部门描述", required = true)
    @ServletDispatcherFieldAlias("unit_desc")
    @NotNull(message = "必须传部门描述字段，空白字符串表示清空描述")
    private String unitDesc;


}
