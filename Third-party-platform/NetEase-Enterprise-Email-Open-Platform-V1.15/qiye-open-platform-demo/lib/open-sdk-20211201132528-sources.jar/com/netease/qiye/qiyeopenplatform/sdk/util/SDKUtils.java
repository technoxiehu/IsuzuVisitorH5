package com.netease.qiye.qiyeopenplatform.sdk.util;

import com.moczul.ok2curl.CurlInterceptor;
import com.moczul.ok2curl.logger.Loggable;
import lombok.extern.slf4j.Slf4j;
import okhttp3.ConnectionPool;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Slf4j
public class SDKUtils {

    public static OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .sslSocketFactory(getSSLSocketFactory(), getTrustManager())
            .connectionPool(new ConnectionPool(10, 60, TimeUnit.SECONDS))
            .hostnameVerifier((s, sslSession) -> true)
            .addInterceptor(new CurlInterceptor(new Loggable() {
                @Override
                public void log(String message) {
                    log.info("发送请求curl\r\n{}\r\n", message);
                }
            }))
            .build();


    /**
     * 发送POST请求
     *
     * @param url
     * @param paramsObj
     * @param headersMap
     * @param requestBodyConvert 载荷转换器，可使用其他content-type
     * @param logEnable          是否打开请求日志
     * @return
     * @throws IOException
     */
    public static String sendPost(String url, Map<String, Object> paramsObj, Map<String, String> headersMap,
                                  Function<Map<String, Object>, RequestBody> requestBodyConvert, boolean logEnable) throws IOException {
        if (logEnable) {
            log.info("请求url:{};请求参数:{};请求头{}",
                    url, CommonUtils.toJSONString(paramsObj), CommonUtils.toJSONString(headersMap));
        }
        RequestBody defaultRequestBody = RequestBody
                .create(MediaType.parse("application/json"),
                        CommonUtils.toJSONString(paramsObj));

        RequestBody requestBody = requestBodyConvert == null
                ? defaultRequestBody
                : requestBodyConvert.apply(paramsObj);

        Headers.Builder headerBuilder = new Headers.Builder();
        Optional.ofNullable(headersMap).orElse(Collections.emptyMap()).entrySet().stream().forEach(e -> {
            if (Objects.nonNull(e.getValue())) {
                headerBuilder.add(e.getKey(), e.getValue());
            }
        });
        Request request = new Request.Builder()
                .url(url)
                .headers(headerBuilder.build())
                .post(requestBody)
                .build();

        Response response = client.newCall(request).execute();
        int httpCode = response.code();
        log.info("请求:" + url + ",HTTP状态码:" + httpCode + "," + response.message());
        return response.body().string();
    }

    private static SSLSocketFactory sslSocketFactory;

    private static X509TrustManager NONE_TRUSTMANAGER;


    public synchronized static SSLSocketFactory getSSLSocketFactory() {
        if (sslSocketFactory != null) {
            return sslSocketFactory;
        }
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, getTrustManagers(), new SecureRandom());
            sslSocketFactory = sslContext.getSocketFactory();
            return sslSocketFactory;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static X509TrustManager[] getTrustManagers() {
        X509TrustManager[] trustAllCerts = new X509TrustManager[]{getTrustManager()};
        return trustAllCerts;
    }

    private static X509TrustManager getTrustManager() {

        if (NONE_TRUSTMANAGER != null) {
            return NONE_TRUSTMANAGER;
        }

        NONE_TRUSTMANAGER = new X509TrustManager() {
            @Override
            public void checkClientTrusted(java.security.cert.X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            @Override
            public void checkServerTrusted(java.security.cert.X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            @Override
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new java.security.cert.X509Certificate[]{};
            }
        };

        return NONE_TRUSTMANAGER;
    }
}
