package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressChangeGroupReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    private String domain;

    @ApiModelProperty(value = "查询返回的addressId,多个则使用英文逗号分隔", required = true)
    @ServletDispatcherFieldAlias("address_ids")
    private String addressIds;

    @ApiModelProperty(value = "分组ID，多个使用英文逗号分隔", required = true)
    @ServletDispatcherFieldAlias("group_ids")
    private String groupIds;

    @ApiModelProperty(value = "是否保留在原分组", required = true)
    private Boolean remain;


}
