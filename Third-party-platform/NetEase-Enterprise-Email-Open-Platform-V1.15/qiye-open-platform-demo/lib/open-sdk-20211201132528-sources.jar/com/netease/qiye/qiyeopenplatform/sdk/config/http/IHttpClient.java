package com.netease.qiye.qiyeopenplatform.sdk.config.http;

import java.io.IOException;
import java.util.Map;

/**
 * 企业服务对外开放接口
 * 统一使用HTTP-JSON
 * 使用自己实例化的HTTP 客户端实现
 * 即可排除 默认的OKHttpClient
 *
 * @author caixianyong
 * @createtime 2021/10/20
 */
public interface IHttpClient {

    /**
     * post
     * application/json;charset=UTF-8
     *
     * @param url
     * @param params     payload JSON
     * @param headersMap headers
     * @param logEnable  request log
     * @return  返回响应体
     * @throws IOException 网络相关的IO异常
     */
    String postJsonData(String url, Map<String, Object> params, Map<String, String> headersMap, boolean logEnable) throws IOException;

}
