package com.netease.qiye.qiyeopenplatform.sdk.service.open;

import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountReq;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountResp;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public interface IAccountService {

    /**
     * 获取账户相关信息
     *
     * @param q
     * @return
     */
    R<AccountResp> getAccount(Q<AccountReq> q);
}
