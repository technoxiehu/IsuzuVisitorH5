package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 * @see MailBoxUnreadMsgReq
 */
@Data
public class MailBoxUnreadMsgReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "邮箱文件夹ID,使用英文半角逗号分开， 默认传1,5 : 1-收件箱;2-草稿箱;3-已发送;4-已删除;5-垃圾邮件")
    @NotBlank(message = "邮箱文件夹ID 不能为空")
    private String fid;

}
