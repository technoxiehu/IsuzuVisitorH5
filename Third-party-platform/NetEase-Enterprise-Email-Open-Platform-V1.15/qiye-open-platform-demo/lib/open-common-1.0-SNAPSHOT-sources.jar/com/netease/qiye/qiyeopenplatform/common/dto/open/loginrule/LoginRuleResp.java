package com.netease.qiye.qiyeopenplatform.common.dto.open.loginrule;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class LoginRuleResp {

    @ApiModelProperty("适用该规则的电子邮箱数组")
    private List<String> accountList;

    @ApiModelProperty("电子邮箱数组大小")
    private Integer accountSize;

    @ApiModelProperty(value = "规则外是否不允许登录（是否拦截），0-允许登录 1-不允许登录")
    private Integer action;

    @ApiModelProperty("IP规则")
    private List<LoginRuleItem> ipList;

    @ApiModelProperty("规则id")
    @JsonAlias("rule_id")
    private Long ruleId;

}
