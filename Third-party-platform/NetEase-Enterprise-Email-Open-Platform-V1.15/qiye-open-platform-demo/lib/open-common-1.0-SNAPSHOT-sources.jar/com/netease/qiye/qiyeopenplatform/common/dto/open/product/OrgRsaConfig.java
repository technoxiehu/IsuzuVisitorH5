package com.netease.qiye.qiyeopenplatform.common.dto.open.product;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/11/30
 */
@Data
public class OrgRsaConfig {

    @JsonAlias("max_request")
    private Integer maxRequest;

    @JsonAlias("org_id")
    private Long orgId;

    private String product;

    @JsonAlias("product_type")
    private Integer productType;

    @JsonAlias("pub_key")
    private String pubKey;

    @JsonAlias("safe_ip")
    private String safeIp;

}
