package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountResp;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @description: 获取账号列表返回
 * @author: ZhuXiaoShu
 * @date: 2021/9/22 9:55
 */
@Data
public class UnitAccountResp {

    @ApiModelProperty(value = "总数")
    private Integer count;

    @ApiModelProperty(value = "分页大小")
    @JsonAlias("page_size")
    private Integer pageSize;

    @ApiModelProperty(value = "分页页码")
    @JsonAlias("page_num")
    private Integer pageNum;

    @ApiModelProperty(value = "账号列表")
    private List<AccountResp> list;

}
