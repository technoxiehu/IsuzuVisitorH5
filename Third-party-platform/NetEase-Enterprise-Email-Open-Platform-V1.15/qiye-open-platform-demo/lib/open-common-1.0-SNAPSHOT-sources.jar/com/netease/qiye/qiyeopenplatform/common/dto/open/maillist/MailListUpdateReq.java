package com.netease.qiye.qiyeopenplatform.common.dto.open.maillist;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailListUpdateReq implements OpenBaseReq {

    @ApiModelProperty(value = "邮件列表名称，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "邮件列表名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "邮件列表名称")
    @ServletDispatcherFieldAlias("nickname")
    private String name;

    @ApiModelProperty(value = "通讯录中是否可见,限定值：1 可见/ 0 不可见")
    @ServletDispatcherFieldAlias("addr_visible")
    private Integer visibleInAddr = 1;

    @ApiModelProperty(value = "邮件列表成员（邮箱）,用英文逗号 , 隔开的邮件地址列表 例如\n" +
            "test1@test.com,test2@test.com")
    @ServletDispatcherFieldAlias("forwardlist")
    private String members;

    @ApiModelProperty(value = "群组列表使用者类型,限定值： 0 允许所有人/ 2 允许列表中的用户和授权用户/ 3 只允许授权用户/ 4 允许域内所有用户")
    @ServletDispatcherFieldAlias("maillist_right")
    private Integer mailListUserType;

    @ApiModelProperty(value = "授权使用邮件列表成员（邮箱）,选填，mailListUserType为2或3时有效\t用英文逗号 , 隔开的帐号列表 例如\n" +
            "admin@test.com,test2@test.com")
    @ServletDispatcherFieldAlias("safelist")
    private String authMembers;

    @ApiModelProperty(value = "授邮件列表成员（部门）",
            notes = "用英文逗号 , 隔开的部门unitid 例如\n" +
                    "123,123456")
    @ServletDispatcherFieldAlias("unitlist")
    private String memberUnits;
}
