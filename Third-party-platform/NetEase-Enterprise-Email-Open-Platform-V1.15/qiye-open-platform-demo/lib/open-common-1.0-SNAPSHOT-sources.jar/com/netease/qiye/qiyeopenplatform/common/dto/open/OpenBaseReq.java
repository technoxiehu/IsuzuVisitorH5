package com.netease.qiye.qiyeopenplatform.common.dto.open;

/**
 * 用于识别是否转换成 ServletDispatcher
 * @see com.netease.qiye.qiyeopenplatform.aspect.OpenParamTransformServletDispatcherFormAspect#transformServletDispatcher(ProceedingJoinPoint, ServletDispatcher, BindingResult)
 * @author caixianyong
 * @createtime 2021/9/13
 */
public interface OpenBaseReq {
}
