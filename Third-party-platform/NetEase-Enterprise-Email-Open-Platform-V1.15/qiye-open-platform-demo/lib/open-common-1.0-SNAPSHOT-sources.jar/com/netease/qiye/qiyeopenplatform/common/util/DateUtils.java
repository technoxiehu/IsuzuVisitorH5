package com.netease.qiye.qiyeopenplatform.common.util;

import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/2
 */
@Slf4j
public class DateUtils {

    public static final String DATE_COMMON = "yyyy-MM-dd";
    public static final String DATETIME_COMMON = "yyyy-MM-dd HH:mm:ss";
    public static final String DATETIME_INFO_COMMON = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String DATETIME_FOR_ID = "yyyyMMddHHmmss";

    /**
     * 当前日期的yyyy-MM-dd HH:mm:ss格式字符串
     *
     * @return
     */
    public static String getNowAsText() {
        return date2Text(getNow(), DATETIME_COMMON);
    }

    public static String getNowAsText(String format) {
        return date2Text(getNow(), format);
    }

    public static String date2Text(Date date, String format) {
        SimpleDateFormat formatDateTime = new SimpleDateFormat(format);
        return formatDateTime.format(date);
    }

    public static Date text2Date(String dateText, String format) {
        SimpleDateFormat formatDateTime = new SimpleDateFormat(format);
        try {
            return formatDateTime.parse(dateText);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * unix 时间戳 毫秒数
     *
     * @param date
     * @return
     */
    public static long unixTimestamp(Date date) {
        return date.getTime();
    }

    public static long unixTimestampSeconds(Date date) {
        return date.getTime() / 1000;
    }

    public static String localDateTime2Text(LocalDateTime dateTime, String format) {
        DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
                .appendPattern(format)
                .toFormatter();
        return dateTime.format(dateTimeFormatter);
    }

    public static LocalDateTime text2LocalDateTime(String dateText, String format) {
        return LocalDateTime.parse(dateText, new DateTimeFormatterBuilder()
                .appendPattern(format)
                .toFormatter());
    }


    private static Date getNow() {
        return new Date();
    }

    private DateUtils() {

    }


}
