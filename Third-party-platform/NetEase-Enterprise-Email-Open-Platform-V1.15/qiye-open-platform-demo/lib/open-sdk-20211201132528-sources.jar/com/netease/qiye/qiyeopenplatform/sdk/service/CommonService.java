package com.netease.qiye.qiyeopenplatform.sdk.service;

import com.netease.qiye.qiyeopenplatform.sdk.QiyeOpenPlatSDKConfig;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;

import java.util.Map;

/**
 * @author caixianyong
 * @createtime 2021/10/21
 */
public class CommonService extends BaseService {

    private QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig;

    /**
     * 解决新接口的请求问题
     * 对于新接口可以使用这种调用方式进行兼容
     * 缺点：失去了对象字段约束以及IDE的智能提醒
     *
     * @param q
     * @param url
     * @return
     */
    public R<Map> commonInvoke(Q<Map> q, String url) {
        return this.requestSDK(q, url);
    }


    @Override
    public QiyeOpenPlatSDKConfig getQiyeOpenPlatSDKConfig() {
        return this.qiyeOpenPlatSDKConfig;
    }

    public CommonService(QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig) {
        this.qiyeOpenPlatSDKConfig = qiyeOpenPlatSDKConfig;
    }
}
