package com.netease.qiye.qiyeopenplatform.common.dto.open.sso;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * login响应的可用于单点登录数据
 * @author caixianyong
 * @createtime 2021/12/1
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsoLoginInfo {

    private String endpoint;

    @JsonAlias("sso_token")
    private String ssoToken;
}
