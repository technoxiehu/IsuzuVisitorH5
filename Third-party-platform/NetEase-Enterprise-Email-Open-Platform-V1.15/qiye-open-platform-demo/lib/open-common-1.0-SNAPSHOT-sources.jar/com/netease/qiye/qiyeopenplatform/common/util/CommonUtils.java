package com.netease.qiye.qiyeopenplatform.common.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.TypeFactory;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author caixianyong
 * @createtime 2021/9/2
 */
@Slf4j
public class CommonUtils {

    public static final Map<String, Map<String, Field>> CLASS_FIELD_MAP = new ConcurrentHashMap<>();

    // 默认jackson对象
    private static ObjectMapper defaultObjectMapper = new ObjectMapper();

    // 使用特定日期格式的jackson对象
    private static ObjectMapper dateFormatObjectMapper = new ObjectMapper();

    static {
        defaultObjectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        dateFormatObjectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public static boolean isStringEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }

    /**
     * 封装一下 方便以后更换json库
     *
     * @param text
     * @param clazz
     * @return
     */
    public static <T> T parseObject(String text, Class<T> clazz) {
        T obj = null;
        if (!isStringEmpty(text)) {
            try {
                obj = defaultObjectMapper.readValue(text, clazz);
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
        return obj;
    }

    public static <T> List<T> parseArray(String text, Class<T> clazz) {
        try {
            return defaultObjectMapper.readValue(text, TypeFactory.defaultInstance()
                    .constructCollectionType(List.class, clazz));
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException("JSON反序列化出错");
        }
    }


    /**
     * 封装一下 方便以后更换json库
     *
     * @param object
     * @return
     */
    public static String toJSONString(Object object) {
        String res = null;
        try {
            res = defaultObjectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error(e.getMessage(), e);
        }
        return res;
    }

    public static Map<String, Field> resolveAccessableFieldMap(Class<?> aClass) {
        String canonicalName = aClass.getCanonicalName();
        Map<String, Field> fieldMap = null;
        if (CLASS_FIELD_MAP.containsKey(canonicalName)) {
            fieldMap = CLASS_FIELD_MAP.get(canonicalName);
        } else {
            //resolve
            fieldMap = Collections.unmodifiableMap(Arrays.stream(aClass.getDeclaredFields())
                    .map(field -> {
                        field.setAccessible(true);
                        return field;
                    })
                    .collect(Collectors.toMap(field -> field.getName(), Function.identity())));
            CLASS_FIELD_MAP.put(canonicalName, fieldMap);
        }
        return fieldMap;
    }

    /**
     * 生成6位随机数验证码
     *
     * @return
     */
    public static String genValidCode() {
        String validCode = "";
        for (int i = 0; i < 6; i++) {
            validCode = validCode + (int) (Math.random() * 9);
        }
        return validCode;
    }

    public static Map<String, Object> beanToMap(Object obj) {
        return beanToMap(obj, 1);
    }

    /**
     * Bean 转 Map
     * @param obj
     * @param depth
     * @return
     */
    public static Map<String, Object> beanToMap(Object obj, int depth) {
        Map<String, Object> map = new HashMap<>(16);
        if (obj == null || depth < 0) {
            return map;
        }
        Class clazz = obj.getClass();
        Class currentClazz = clazz;
        Class lastClazz = clazz;

        int targetDepth = depth == 0 ? Integer.MAX_VALUE : depth;

        for (int i = 0; i < targetDepth; i++) {
            Map<String, Field> fieldMap = resolveAccessableFieldMap(currentClazz);
            for (Field field : fieldMap.values()) {
                try {
                    map.put(field.getName(), field.get(obj));
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }

            lastClazz = currentClazz;
            currentClazz = clazz.getSuperclass();
            if (currentClazz == lastClazz || currentClazz == null) {
                break;
            }
        }
        return map;
    }

    private CommonUtils() {
    }
}
