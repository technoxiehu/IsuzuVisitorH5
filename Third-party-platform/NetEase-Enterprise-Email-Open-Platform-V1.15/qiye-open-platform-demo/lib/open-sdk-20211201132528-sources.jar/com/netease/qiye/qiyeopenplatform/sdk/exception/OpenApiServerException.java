package com.netease.qiye.qiyeopenplatform.sdk.exception;

/**
 * 服务端异常
 *
 * @author caixianyong
 * @createtime 2021/10/22
 */
public class OpenApiServerException extends RuntimeException {

    private String msg;

    public OpenApiServerException(String msg) {
        super(msg);
        this.msg = msg;
    }
}