package com.netease.qiye.qiyeopenplatform.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 请求实体 相对 ServletDispatcher的内部服务字段映射
 * @see com.netease.qiye.qiyeopenplatform.manager.api.entity.ServletDispatcher
 *
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ServletDispatcherFieldAlias {

    String value();

    Class expectedClass() default Void.class;

    String datePattern() default "";

}
