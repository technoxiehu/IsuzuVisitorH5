package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 * @see MailBoxListMsgPageReq
 */
@Data
public class MailBoxListMsgPageReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "邮箱文件夹ID,使用英文半角逗号分开， 默认传1,5 : 1-收件箱;2-草稿箱;3-已发送;4-已删除;5-垃圾邮件")
    @NotBlank(message = "邮箱文件夹ID 不能为空")
    private String fid;

    @ApiModelProperty(value = "分页数，不填默认不分页")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小，默认最大都为50")
    @Range(min = 1, max = 50, message = "分页大小 不能超过50，亦不小于1")
    @ServletDispatcherFieldAlias("limit")
    private Integer pageSize = 50;

    @ApiModelProperty(value = "是否返回邮件总数, 默认不返回")
    private Boolean returnTotal = false;

    @ApiModelProperty(value = "排序字段,默认：receivedDate")
    private String order = "receivedDate";

    @ApiModelProperty(value = "是否倒序")
    @ServletDispatcherFieldAlias(value = "desc", expectedClass = Boolean.class)
    private Boolean desc = true;

}
