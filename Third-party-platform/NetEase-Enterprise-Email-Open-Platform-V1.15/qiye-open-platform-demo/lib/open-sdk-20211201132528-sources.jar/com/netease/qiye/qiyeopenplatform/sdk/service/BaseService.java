package com.netease.qiye.qiyeopenplatform.sdk.service;

import com.netease.qiye.qiyeopenplatform.common.constant.OpenPlatRequestPartConstant;
import com.netease.qiye.qiyeopenplatform.common.util.CodecUtils;
import com.netease.qiye.qiyeopenplatform.sdk.QiyeOpenPlatSDKConfig;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;
import com.netease.qiye.qiyeopenplatform.sdk.exception.OpenApiIOException;
import com.netease.qiye.qiyeopenplatform.sdk.exception.OpenApiServerException;
import com.netease.qiye.qiyeopenplatform.sdk.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Slf4j
public abstract class BaseService {

    public abstract QiyeOpenPlatSDKConfig getQiyeOpenPlatSDKConfig();

    public R requestSDK(Q q, String urlSuffix) {

        QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig = this.getQiyeOpenPlatSDKConfig();

        Map paramMap = q.getParamMap();
        //处理请求头
        //对外开放平台仅支持唯一请求头
        Map<String, String> headerMap = q.getHeaderMap();

        //全局请求头，仅从SDKConfig获取相关调用参数
        headerMap.put(OpenPlatRequestPartConstant.HEADER_ACCESS_TOKEN, qiyeOpenPlatSDKConfig.getAccessToken());
        headerMap.put(OpenPlatRequestPartConstant.HEADER_APP_ID, qiyeOpenPlatSDKConfig.getAppId());
        headerMap.put(OpenPlatRequestPartConstant.HEADER_ORG_OPEN_ID, qiyeOpenPlatSDKConfig.getOrgOpenId());
        //默认填充，允许参数Q定制请求头
        headerMap.putIfAbsent(OpenPlatRequestPartConstant.HEADER_TIMESTAMP, Long.toString(System.currentTimeMillis()));
        headerMap.putIfAbsent(OpenPlatRequestPartConstant.HEADER_NONCE, CodecUtils.hexEncode(CodecUtils.generateRandom(6)));

        //请求头处理回调
        Map applyHeaderMap = this.getQiyeOpenPlatSDKConfig().getHeaderCallback().apply(paramMap, headerMap);

        String urlPrefix = qiyeOpenPlatSDKConfig.getUrlPrefix();

        //发送POST请求
        String resultStr = null;
        String url = urlPrefix + urlSuffix;
        try {
            resultStr = qiyeOpenPlatSDKConfig.getHttpClient().postJsonData(url, paramMap, applyHeaderMap, qiyeOpenPlatSDKConfig.isLogEnable());
        } catch (IOException e) {
            //抛出指定异常
            throw new OpenApiIOException(e.getMessage());
        }
        log.info("请求接口{}: \n响应值(payload):{}", url, resultStr);

        if (CommonUtils.isStringEmpty(resultStr)
                && resultStr.startsWith("{") && resultStr.startsWith("}")) {
            //抛出指定异常 TODO
            throw new OpenApiServerException("服务端响应异常，返回值不符合JSON格式");
        }
        R r = CommonUtils.parseObject(resultStr, R.class);
        if (Objects.isNull(r)) {
            //抛出指定异常 TODO
            throw new OpenApiServerException("服务端响应异常，反序列化失败");
        }
        r.setResponseText(resultStr);
        return r;
    }

}
