package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 * @see AccountLoginReq
 */
@Data
public class AccountLoginReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "登录权限名,web、flashmail、imap、pop、smtp、activesync、dashi、sirius", required = true)
    @ServletDispatcherFieldAlias("login_type")
    @NotBlank(message = "登录权限名 不能为空")
    private String loginType;

    @ApiModelProperty(value = "登录权限值,0-无法使用，1-可以使用", required = true)
    @ServletDispatcherFieldAlias("login_perm")
    @NotNull(message = "登录权限值 不能为空")
    private Integer loginPerm;

}
