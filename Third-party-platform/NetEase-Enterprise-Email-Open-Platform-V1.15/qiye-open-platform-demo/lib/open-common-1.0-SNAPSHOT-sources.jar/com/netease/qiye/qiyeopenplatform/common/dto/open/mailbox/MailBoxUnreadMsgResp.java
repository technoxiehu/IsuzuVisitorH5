package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailBoxUnreadMsgResp {

    @ApiModelProperty(value = "未读邮件数量")
    private Long count;

}
