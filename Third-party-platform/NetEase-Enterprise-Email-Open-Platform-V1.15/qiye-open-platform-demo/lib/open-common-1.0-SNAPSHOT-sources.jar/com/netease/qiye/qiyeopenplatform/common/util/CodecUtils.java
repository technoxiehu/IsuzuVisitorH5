package com.netease.qiye.qiyeopenplatform.common.util;

import lombok.extern.slf4j.Slf4j;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.UUID;

/**
 * @author caixianyong
 * @createtime 2021/9/2
 */
@Slf4j
public class CodecUtils {

    private static Random RANDOM_INSTANCE = new Random();

    /**
     * Used to build output as Hex
     */
    private static final char[] DIGITS_LOWER = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
            'e', 'f'};

    /**
     * Used to build output as Hex
     */
    private static final char[] DIGITS_UPPER = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D',
            'E', 'F'};

    private static final char[] HEX_TEXT_MAPPING = new char[256];

    static {
        // init
        for (int i = 0; i < DIGITS_LOWER.length; i++) {
            HEX_TEXT_MAPPING[DIGITS_LOWER[i]] = (char) i;
        }
        for (int i = 0; i < DIGITS_UPPER.length; i++) {
            HEX_TEXT_MAPPING[DIGITS_UPPER[i]] = (char) i;
        }
    }

    /**
     * 所有大小写字母和数字
     */
    public static final char[] allCharArr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    /**
     * 所有大小写字母
     */
    public static final char[] letterCharArr = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    /**
     * 所有数字
     */
    public static final char[] numberCharArr = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

    /**
     * 项目统一
     * 大写hex
     *
     * @param content
     * @return
     * @throws
     */
    public static String hexEncode(byte[] content) {
        return hexEncode(true, content);
    }

    public static String hexEncode(boolean cap, byte[] content) {
        final int l = content.length;
        final char[] out = new char[l << 1];

        char[] toDigits = cap ? DIGITS_UPPER : DIGITS_LOWER;
        // two characters form the hex value.
        for (int i = 0, j = 0; i < l; i++) {
            out[j++] = toDigits[(0xF0 & content[i]) >>> 4];
            out[j++] = toDigits[0x0F & content[i]];
        }
        return new String(out);
    }

    public static byte[] hexDecode(String hexText) {
        if (hexText.length() % 2 != 0) {
            throw new RuntimeException("not hex text");
        }
        byte[] bytes = new byte[hexText.length() / 2];
        char[] chars = hexText.toCharArray();
        // two characters form the hex value.
        StringBuilder stringBuilder = new StringBuilder(hexText);
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte) (HEX_TEXT_MAPPING[chars[2 * i]] << 4 | (0x0F & HEX_TEXT_MAPPING[chars[2 * i + 1]]));
        }
        return bytes;
    }

    // UTF8普遍支持
    public static String urlEncode(String origin) {
        try {
            return URLEncoder.encode(origin, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String urlDecode(String origin) {
        try {
            return URLDecoder.decode(origin, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static String base64Encode(byte[] content) {
        return java.util.Base64.getEncoder().encodeToString(content);
    }

    public static byte[] base64Decode(String text) {
        return java.util.Base64.getDecoder().decode(text);
    }

    /**
     * 32 UUID
     *
     * @return
     */
    public static String generateUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * 生成随机数
     *
     * @param length 字节数
     * @return
     */
    public static byte[] generateRandom(int length) {

        if (length <= 0) {
            throw new RuntimeException("random size must more than 0");
        }
        byte[] result = new byte[length];
        RANDOM_INSTANCE.nextBytes(result);
        return result;
    }

    private CodecUtils() {
    }

}
