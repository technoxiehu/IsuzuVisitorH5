package com.netease.qiye.qiyeopenplatform.common.dto.login;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/8
 */
@Data
public class AppLogoutReq {

    @NotBlank(message = "appId 不能为空")
    @ApiModelProperty(value = "应用ID", required = true)
    private String accessToken;

}
