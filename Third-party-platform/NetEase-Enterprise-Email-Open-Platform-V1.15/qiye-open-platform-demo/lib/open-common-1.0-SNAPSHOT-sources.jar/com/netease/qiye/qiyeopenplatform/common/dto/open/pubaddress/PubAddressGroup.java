package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressGroup {

    @ApiModelProperty(value = "分组ID")
    @JsonAlias("group_id")
    private Long groupId;

    @ApiModelProperty(value = "分组名称")
    private String name;

    @ApiModelProperty(value = "顶级分组: -1; 非顶级分组：父分组id")
    @JsonAlias("parent_id")
    private Long parentId;

    @ApiModelProperty(value = "分组排序")
    private Integer rank;
}
