package com.netease.qiye.qiyeopenplatform.common.dto.open.logquery;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class LoginLogQueryResp {

    // 登录账户名：主账号
    @ApiModelProperty("登录账户名：主账号")
    @JsonAlias("account_name")
    private String accountName;

    // 登录时间
    @ApiModelProperty("登录时间")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date time;

    // 登录类型
    @ApiModelProperty("登录类型")
    private String type;

    // 登录ip
    private String ip;

    @ApiModelProperty(value = "该小时内登录次数，web登录日志不支持")
    private int num;

}
