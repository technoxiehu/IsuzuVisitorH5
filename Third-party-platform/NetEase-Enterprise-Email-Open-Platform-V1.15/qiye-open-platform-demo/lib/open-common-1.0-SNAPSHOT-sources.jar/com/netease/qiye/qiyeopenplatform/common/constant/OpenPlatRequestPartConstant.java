package com.netease.qiye.qiyeopenplatform.common.constant;

import lombok.Getter;

/**
 * @author caixianyong
 * @createtime 2021/9/9
 */
@Getter
public class OpenPlatRequestPartConstant {

    // region headers
    //open api 调用凭证
    public static final String HEADER_ACCESS_TOKEN = "qiye-access-token";
    //sso api 调用凭证
    public static final String HEADER_SSO_AUTH_TOKEN = "qiye-sso-auth-token";
    //定位服务辅助（TODO 后面变更 可能只需要 org-open-id）
    public static final String HEADER_DOMAIN = "qiye-domain";

    // 调用凭证辅助
    public static final String HEADER_APP_ID = "qiye-app-id";
    public static final String HEADER_ORG_OPEN_ID = "qiye-org-open-id";

    // 接口防重放
    // 时间戳
    public static final String HEADER_TIMESTAMP = "qiye-timestamp";
    // 客户端随机值
    public static final String HEADER_NONCE = "qiye-nonce";

    // TODO 结合后续网关开发
    // 签名参数-算法

    // 签名实现-版本

    // 接口签名（TODO）
    public static final String HEADER_SIGNATURE = "qiye-signature";

    // end region


    // 查询参数，查询token
    public static final String QUERY_STRING_REFRESH_TOKEN = "refreshToken";

}
