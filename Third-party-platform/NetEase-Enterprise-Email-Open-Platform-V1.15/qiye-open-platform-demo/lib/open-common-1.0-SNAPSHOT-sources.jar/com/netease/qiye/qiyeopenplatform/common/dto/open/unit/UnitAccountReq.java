package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: SaromChars
 */
@Data
public class UnitAccountReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名不能为空")
    private String domain;

    @ApiModelProperty(value = "部门id")
    @ServletDispatcherFieldAlias("unit_id")
    private String unitId;

    @ApiModelProperty(value = "是否包含子部门账号")
    private Boolean recursion;

    @ApiModelProperty(value = "分页数")
    @ServletDispatcherFieldAlias("page_num")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小,默认最大都为50")
    @ServletDispatcherFieldAlias("page_size")
    @Range(min = 1, max = 50, message = "分页大小 不能超过50，亦不能小于1")
    private Integer pageSize = 50;


}
