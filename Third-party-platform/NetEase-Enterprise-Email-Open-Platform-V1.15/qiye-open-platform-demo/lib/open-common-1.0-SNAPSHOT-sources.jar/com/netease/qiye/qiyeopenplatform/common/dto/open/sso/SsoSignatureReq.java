package com.netease.qiye.qiyeopenplatform.common.dto.open.sso;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/11/30
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsoSignatureReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @NotBlank(message = "账号名称 不能为空")
    @ServletDispatcherFieldAlias(value = "account_name")
    public String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

}
