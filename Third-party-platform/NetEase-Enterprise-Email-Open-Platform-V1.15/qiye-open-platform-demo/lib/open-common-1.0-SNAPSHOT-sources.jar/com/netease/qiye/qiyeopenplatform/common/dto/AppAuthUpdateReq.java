package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * @description: 应用授权请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/2 10:50
 */
@Data
public class AppAuthUpdateReq {

    @ApiModelProperty(value = "授权ID", required = true)
    @NotNull(message = "授权ID 不能为空")
    private Long id;

    @ApiModelProperty(value = "权限ID集,多个用,分割")
    private String permissionIdSet;

    @ApiModelProperty(value = "可访问IP集,多个用,分割")
    private String accessIpSet;

    @ApiModelProperty(value = "状态 0正常 1冻结")
    @Range(min = 0, max = 1, message = "0正常 1冻结")
    private Integer status;
}
