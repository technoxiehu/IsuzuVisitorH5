package com.netease.qiye.qiyeopenplatform.common.dto.open.archive;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class ArchiveSearchResp {

    @ApiModelProperty(value = "页码")
    private Integer page;

    @ApiModelProperty(value = "总页数")
    private Integer pageTotal;

    @ApiModelProperty(value = "页大小")
    private Integer size;

    @ApiModelProperty(value = "总数量")
    private Integer total;

    @ApiModelProperty(value = "当前页数据")
    private List<ArchiveEmailInfo> result;

}
