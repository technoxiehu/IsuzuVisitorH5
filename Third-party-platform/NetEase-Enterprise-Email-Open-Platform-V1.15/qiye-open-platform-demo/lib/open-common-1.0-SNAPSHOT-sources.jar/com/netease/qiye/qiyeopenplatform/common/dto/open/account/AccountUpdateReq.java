package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class AccountUpdateReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "用户姓名")
    @ServletDispatcherFieldAlias("nickname")
    private String name;

    @ApiModelProperty(value = "是否具有查看企业通讯录权限")
    @ServletDispatcherFieldAlias("addr_right")
    private Integer enableAccessAddr;

    @ApiModelProperty(value = "是否企业通讯录中显示")
    @ServletDispatcherFieldAlias("addr_visible")
    private Integer visibleInAddr;

    @ApiModelProperty(value = "用户账户有效期止,格式为：" + DateUtils.DATE_COMMON)
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATE_COMMON)
    @ServletDispatcherFieldAlias(value = "exp_time", datePattern = DateUtils.DATE_COMMON)
    private Date expiredTime;

    @ApiModelProperty(value = "是否具有自动转发权限")
    @ServletDispatcherFieldAlias("fwd")
    private Integer enableFwd;

    @ApiModelProperty(value = "配置自动转发是否验证")
    @ServletDispatcherFieldAlias("fwdmauth")
    private Integer fwdMAuth;

    @ApiModelProperty(value = "工号")
    @ServletDispatcherFieldAlias("job_no")
    private String jobNumber;

    @ApiModelProperty(value = "职位")
    private String job;

    @ApiModelProperty(value = "是否禁止主账号登录,默认0, 不禁止")
    @ServletDispatcherFieldAlias("main_account_login_forbidden")
    private Integer mainAccountLoginForbidden;

    @ApiModelProperty(value = "手机号码")
    private String mobile;

    @ApiModelProperty(value = "首次登录修改密码要求,0-不需要，1-web登录需要，客户端不需要，2-web登录需要且未改密码前客户端不能登录")
    @ServletDispatcherFieldAlias("passchange_req")
    private Integer passChangeFirstLogin;

    @ApiModelProperty(value = "是否允许将军令重置密码")
    @ServletDispatcherFieldAlias("resetpass_general")
    private Integer enableCommonResetPass;

    @ApiModelProperty(value = "是否允许手机重置密码")
    @ServletDispatcherFieldAlias("resetpass_mobile")
    private Integer enableMobileResetPass;

    @ApiModelProperty(value = "是否禁止客户端pop删信,0:允许pop删信;1:禁止pop删信;-1:不修改")
    @ServletDispatcherFieldAlias("pop_delete")
    private Integer popDelete;

    @ApiModelProperty(value = "强制二步验证,0 -不强制,1-强制,-1不更改")
    @ServletDispatcherFieldAlias("secondary_logon")
    private Integer secondaryLogon;

    @ApiModelProperty(value = "所属部门id,默认部门传\"default\",多个部门用英文半角逗号分隔")
    @ServletDispatcherFieldAlias("unit_id")
    private String unitId = "default";

    @ApiModelProperty(value = "性别,0-男，1-女，-1-保密")
    private Integer gender;

    @ApiModelProperty(value = "办公电话")
    private String tel;

    @ApiModelProperty(value = "传真")
    private String fax;

    @ApiModelProperty(value = "备注")
    private String remark;

    //TODO i18n
    @ApiModelProperty(value = "国籍,传值参考最后页备注国家值, 传完整(汉字+英文),不传默认值为”中国China”")
    private String state;

    @ApiModelProperty(value = "国内证件类型,（当state值为”中国China”时）传该值        0:身份证号， 1：港澳通行证， 2：台湾通行证,3,中国护照。默认值为0")
    @ServletDispatcherFieldAlias("card_type")
    private Integer cardType;

    @ApiModelProperty(value = "国内证件号,（当state值为”中国China”时）传值     String，该字段支持空值")
    @ServletDispatcherFieldAlias("card_id")
    private String cardNum;

    @ApiModelProperty(value = "外国护照号,（当state值非”中国China”时）传值      String，该字段支持空值")
    private String passport;

    @ApiModelProperty(value = "是否可以使用云附件,1-可以，0-不可以")
    @ServletDispatcherFieldAlias("big_attachment")
    private Integer enableCloudAttachment;

    @ApiModelProperty(value = "是否可以使用邮箱大师私有协议,1-可以，0-不可以，默认可以")
    @ServletDispatcherFieldAlias("dashi")
    private Integer enableEmailMasterProtocol;

    @ApiModelProperty(value = "通讯录账号显示的邮箱地址，主账号邮箱或者是别名邮箱地址")
    @ServletDispatcherFieldAlias("display_email")
    private String displayEmail;

}
