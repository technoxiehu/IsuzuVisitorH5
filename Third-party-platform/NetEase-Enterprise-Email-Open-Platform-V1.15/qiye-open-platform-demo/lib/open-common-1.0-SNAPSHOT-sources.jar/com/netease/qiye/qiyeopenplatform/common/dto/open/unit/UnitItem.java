package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: SaromChars
 */
@Data
public class UnitItem {

//    @JsonAlias("org_id")
//    private Long orgId;

    @ApiModelProperty(value = "部门openId")
    @JsonAlias("ouid")
    private String unitOpenId;

    @ApiModelProperty(value = "部门id")
    @JsonAlias("unit_id")
    private String unitId;

    @ApiModelProperty(value = "父部门id")
    @JsonAlias("parent_id")
    private String unitParentId;

    @ApiModelProperty(value = "部门名称")
    @JsonAlias("unit_name")
    private String unitName;

    @ApiModelProperty(value = "部门排序")
    @JsonAlias("unit_rank")
    private Integer rank;

    @ApiModelProperty(value = "部门描述")
    @JsonAlias("unit_desc")
    private String unitDesc;
}
