package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class DomainResp {

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "企业名称")
    @JsonAlias("org_name")
    private String orgName;

    @ApiModelProperty(value = "过期时间")
    @JsonAlias("exp_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date expTime;

    private String logo;

    @ApiModelProperty(value = "企业openID")
    @JsonAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "域名openID")
    @JsonAlias("domain_openid")
    private String domainOpenId;

    @ApiModelProperty(value = "是否企业通讯录中显示")
    @JsonAlias("addr_visible")
    private String visibleInAddr;

}
