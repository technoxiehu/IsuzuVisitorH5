package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressGroupRenameReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    private String domain;

    @ApiModelProperty(value = "分组ID", required = true)
    @ServletDispatcherFieldAlias("group_id")
    private Long groupId;

    @ApiModelProperty(value = "分组名称", required = true)
    private String name;

}
