package com.netease.qiye.qiyeopenplatform.common.dto.open.push;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/16
 */
@Data
public class PushResp {

    private Long id;

    private String name;

    @JsonAlias("interfaceAddr")
    private String url;

    private String source;
}
