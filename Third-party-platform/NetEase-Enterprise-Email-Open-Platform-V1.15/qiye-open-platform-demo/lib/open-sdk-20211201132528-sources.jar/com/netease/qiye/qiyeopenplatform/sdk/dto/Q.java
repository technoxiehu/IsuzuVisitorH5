package com.netease.qiye.qiyeopenplatform.sdk.dto;

import com.netease.qiye.qiyeopenplatform.sdk.util.CommonUtils;
import lombok.Data;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Data
public class Q<T> {

    /**
     * 额外参数，用于临时添加版本新参数
     */
    private Map<String, Object> paramMap = null;
    private Map<String, Object> headerMap = null;
    private T req = null;

    public static <T> Q<T> init(T o) {
        return new Q(o);
    }

    /**
     * 拓展参数
     *
     * @param key
     * @param value
     * @return
     */
    public Q addParam(String key, Object value) {
        if (value instanceof String
                || value instanceof Integer || value instanceof Long
                || value instanceof Boolean
                || value instanceof Date
                || value instanceof Map
                || value instanceof List) {
            paramMap.put(key, value);
        } else {
            throw new RuntimeException("不支持的数据类型：" + value.getClass().getName());
        }
        return this;
    }

    /**
     * @return
     */
    public Q removeParam(String key) {
        paramMap.remove(key);
        return this;
    }

    /**
     * 拓展请求头
     *
     * @param key
     * @param value
     * @return
     */
    public Q addHeader(String key, Object value) {
        if (value instanceof String) {
            headerMap.put(key, value);
        } else {
            throw new RuntimeException("不支持的数据类型：" + value.getClass().getName());
        }
        return this;
    }

    /**
     * @return
     */
    public Q removeHeader(String key) {
        headerMap.remove(key);
        return this;
    }

    private Q(T o) {
        req = o;
        paramMap = Objects.isNull(req) ? new HashMap<>() : CommonUtils.beanToMapJson(req);
        headerMap = new HashMap<>();
    }

}
