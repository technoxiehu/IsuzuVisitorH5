package com.netease.qiye.qiyeopenplatform.common.dto.open.mobile;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailMobileSmsStatusReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "用户账号名 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "手机号码", required = true)
    @NotBlank(message = "手机号码 不能为空")
    private String mobile;

    @ApiModelProperty(required = true, value = "是否激活随身邮,状态：0-不激活，1-激活")
    @NotNull(message = "是否激活随身邮 不能为空")
    @Range(min = 0, max = 1, message = "该值仅能接受值为 0 - 1")
    private Integer status;
}
