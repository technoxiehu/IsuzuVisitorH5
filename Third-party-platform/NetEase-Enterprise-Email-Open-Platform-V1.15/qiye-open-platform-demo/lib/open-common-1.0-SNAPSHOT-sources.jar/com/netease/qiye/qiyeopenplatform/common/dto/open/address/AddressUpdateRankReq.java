package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class AddressUpdateRankReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true, value = "排序值, 1-表示第一位，以此类推")
    @NotNull(message = "排序值 不能为空")
    private Integer rank;
}
