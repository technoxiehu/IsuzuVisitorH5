package com.netease.qiye.qiyeopenplatform.sdk.config.json;

import java.util.List;

/**
 * 企业服务对外开放接口
 * 统一使用HTTP-JSON
 * 使用自己实例化的HTTP 客户端实现
 * 即可排除 默认的OKHttpClient
 *
 * @author caixianyong
 * @createtime 2021/10/20
 */
public interface IJson {

    /**
     * 序列化为JSON
     * 非空
     *
     * @param o
     * @return 失败则返回Null
     */
    String toJsonString(Object o);

    /**
     * 反序列化为对象
     * 兼容大小写
     * 非空不处理
     *
     * @param jsonText
     * @param c
     * @param <T>
     * @return 失败则返回Null
     */
    <T> T parseObject(String jsonText, Class<T> c);

    /**
     * 反序列化为list
     * 兼容大小写
     * 非空不处理
     *
     * @param jsonText
     * @param c
     * @param <T>
     * @return 失败抛异常
     */
    <T> List<T> parseList(String jsonText, Class<T> c);
}
