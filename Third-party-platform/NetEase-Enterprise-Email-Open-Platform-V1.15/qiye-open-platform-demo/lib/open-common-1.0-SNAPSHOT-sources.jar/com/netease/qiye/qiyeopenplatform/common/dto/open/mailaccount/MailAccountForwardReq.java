package com.netease.qiye.qiyeopenplatform.common.dto.open.mailaccount;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class MailAccountForwardReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "accountName 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "domain 不能为空")
    private String domain;

    @ApiModelProperty(value = "自动转发邮箱地址", required = true)
    @ServletDispatcherFieldAlias("forwarddes")
    @NotBlank(message = "forwardAddress 不能为空")
    private String forwardAddress;

}
