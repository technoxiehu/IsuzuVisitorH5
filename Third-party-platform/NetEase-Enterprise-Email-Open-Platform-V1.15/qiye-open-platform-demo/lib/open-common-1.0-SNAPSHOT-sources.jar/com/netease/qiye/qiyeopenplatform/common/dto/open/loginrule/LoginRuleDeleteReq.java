package com.netease.qiye.qiyeopenplatform.common.dto.open.loginrule;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class LoginRuleDeleteReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "规则Id", required = true)
    @ServletDispatcherFieldAlias("rule_id")
    @NotNull(message = "规则Id 不能为空")
    private Long ruleId;

}
