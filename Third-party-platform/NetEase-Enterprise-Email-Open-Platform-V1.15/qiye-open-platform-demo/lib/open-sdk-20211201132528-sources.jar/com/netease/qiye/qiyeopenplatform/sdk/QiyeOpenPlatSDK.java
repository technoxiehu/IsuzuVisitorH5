package com.netease.qiye.qiyeopenplatform.sdk;

import com.netease.qiye.qiyeopenplatform.common.dto.login.AppLoginResp;
import com.netease.qiye.qiyeopenplatform.common.dto.login.SsoLoginResp;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountReq;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountResp;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;
import com.netease.qiye.qiyeopenplatform.sdk.service.CommonService;
import com.netease.qiye.qiyeopenplatform.sdk.service.open.AccountService;
import com.netease.qiye.qiyeopenplatform.sdk.service.open.IAccountService;
import com.netease.qiye.qiyeopenplatform.sdk.service.pub.IPubService;
import com.netease.qiye.qiyeopenplatform.sdk.service.pub.PubService;
import lombok.Getter;

import java.util.Map;
import java.util.Objects;

/**
 * SDK入口类
 *
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Getter
public class QiyeOpenPlatSDK implements IPubService, IAccountService {

    private String name;
    private QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig;

    public QiyeOpenPlatSDK(String name, QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig) {
        if (Objects.isNull(qiyeOpenPlatSDKConfig)) {
            throw new RuntimeException("缺少SDK配置对象");
        }
        this.name = name;
        this.qiyeOpenPlatSDKConfig = qiyeOpenPlatSDKConfig;

        //注册服务 TODO
        commonService = new CommonService(qiyeOpenPlatSDKConfig);
        pubService = new PubService(qiyeOpenPlatSDKConfig);
        accountService = new AccountService(qiyeOpenPlatSDKConfig);
    }

    private CommonService commonService;
    private IPubService pubService;
    private IAccountService accountService;

    public R<Map> commonInvoke(Q<Map> q, String url) {
        return commonService.commonInvoke(q, url);
    }

    @Override
    public R<AppLoginResp> appLogin(String authCode) {
        return pubService.appLogin(authCode);
    }

    @Override
    public R<AppLoginResp> refreshToken() {
        return pubService.refreshToken();
    }

    @Override
    public R<SsoLoginResp> ssoAuthToken(String authCode) {
        return pubService.ssoAuthToken(authCode);
    }

    @Override
    public R<AccountResp> getAccount(Q<AccountReq> q) {
        return accountService.getAccount(q);
    }
}