package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;

/**
 * @description: 应用授权请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/2 10:50
 */
@Data
public class AppAuthCreateReq {

    @ApiModelProperty(value = "应用ID", required = true)
    @NotBlank(message = "应用ID 不能为空")
    private String appId;

    @ApiModelProperty(value = "企业OpenID", required = true)
    @NotBlank(message = "企业OpenID 不能为空")
    private String orgOpenId;

    @ApiModelProperty(value = "权限ID集,多个用,分割")
    private String permissionIdSet;

    @ApiModelProperty(value = "可访问IP集,多个用,分割")
    private String accessIpSet;

    @ApiModelProperty(value = "access token在持续时间(秒)内有效，默认86400s")
    @Range(min = 10 * 60, max = 7 * 24 * 60 * 60, message = "access token 有效期最小不能小于10min 最大不能大于7d")
    private Long tokenExpired = 86_400L;

    @ApiModelProperty(value = "refresh token在持续时间(小时)内有效，默认24h")
    @Range(min = 24, max = 2 * 365 * 24, message = "refresh token 有效期最小不能小于1d 最大不能大于2y")
    private Long refreshExpired = 24L;
}
