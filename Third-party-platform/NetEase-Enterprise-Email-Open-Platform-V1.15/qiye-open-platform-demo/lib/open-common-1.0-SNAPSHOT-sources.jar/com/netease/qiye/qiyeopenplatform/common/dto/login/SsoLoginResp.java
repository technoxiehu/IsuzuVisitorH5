package com.netease.qiye.qiyeopenplatform.common.dto.login;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * 单点登录token
 * @author caixianyong
 * @createtime 2021/9/8
 */
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class SsoLoginResp {

    @ApiModelProperty(value = "单点登录辅助凭证")
    private String ssoAuthToken;

    @JsonFormat(pattern = DateUtils.DATETIME_COMMON, timezone = "gmt+8")
    @ApiModelProperty(value = "单点登录辅助凭证有效期截止")
    private Date ssoAuthTokenExpiredTime;

}
