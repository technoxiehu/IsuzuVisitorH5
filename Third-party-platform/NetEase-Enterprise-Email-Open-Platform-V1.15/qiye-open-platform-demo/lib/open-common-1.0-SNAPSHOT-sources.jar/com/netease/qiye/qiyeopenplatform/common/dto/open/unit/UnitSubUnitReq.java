package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class UnitSubUnitReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名不能为空")
    private String domain;

    @ApiModelProperty(value = "部门id", required = true)
    @ServletDispatcherFieldAlias("unit_id")
    @NotBlank(message = "指定部门Id不能为空")
    private String unitId;

    @ApiModelProperty(value = "是否递归取子部门的子部门")
    private Boolean recursion;


}
