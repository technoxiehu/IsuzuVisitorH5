package com.netease.qiye.qiyeopenplatform.common.dto.open.push;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/16
 */
@Data
public class PushOperateReq implements OpenBaseReq {

    @ApiModelProperty(required = true, value = "企业OpenId,企业邮提供的企业对应OpenId")
    @NotBlank(message = "orgOpenId 不能为空")
    @ServletDispatcherFieldAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "推送消息类型,推送消息类型（新邮件到达为pushmail、组织变更orgevent）,默认为：pushmail")
    private String source = "pushmail";

}
