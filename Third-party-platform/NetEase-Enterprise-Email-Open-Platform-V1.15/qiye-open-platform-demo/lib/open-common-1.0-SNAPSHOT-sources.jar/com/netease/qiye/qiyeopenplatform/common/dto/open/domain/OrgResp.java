package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class OrgResp {

    @ApiModelProperty(value = "是否具有查看企业通讯录权限")
    @JsonAlias("addr_right")
    private Integer enableAccessAddr;

    @ApiModelProperty(value = "是否企业通讯录中显示")
    @JsonAlias("addr_visible")
    private Integer visibleInAddr;

    @ApiModelProperty(value = "企业openID")
    @JsonAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "企业名称")
    @JsonAlias("org_name")
    private String orgName;

    @ApiModelProperty(value = "企业组织数据的创建时间")
    @JsonAlias("create_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date createTime;

    @ApiModelProperty(value = "是否已删除")
    private Boolean deleted;

    @ApiModelProperty(value = "域名列表")
    @JsonAlias("domain_list")
    private List<DomainInfoItem> domainList;
}
