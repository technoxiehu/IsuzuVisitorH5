package com.netease.qiye.qiyeopenplatform.common.dto.open.mailaccount;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class MailAccountForwardResp implements OpenBaseReq {

    @ApiModelProperty(value = "自动转发状态, 1-启用，其他-未启用）")
    @JsonAlias("forwardactive")
    private Integer forwardActive;

    @ApiModelProperty(value = "转发地址")
    @JsonAlias("forwarddes")
    private String forwardAddress;

    @ApiModelProperty(value = "是否有自动转发权限 0-否，1-是")
    @JsonAlias("fwd")
    private Integer enableFwd;

    @ApiModelProperty(value = "自动转发是否需要手机验证 0-否，1-是")
    @JsonAlias("fwdmauth")
    private Integer fwdMAuth;

    @ApiModelProperty(value = "自动转发是否在本地保存（1-是，其他-否）")
    @JsonAlias("keeploacl")
    private String keepLocal;

}
