package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 同一换成openId
 *
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class UnitMoveReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名不能为空")
    private String domain;

    @ApiModelProperty(value = "部门id", required = true)
    @ServletDispatcherFieldAlias("unit_id")
    @NotBlank(message = "部门Id不能为空")
    private String unitId;

    @ApiModelProperty(value = "期望父部门id，移动为顶级/根部门，则该值为'root'", required = true)
    @ServletDispatcherFieldAlias("new_parent_id")
    @NotBlank(message = "父部门Id不能为空")
    private String unitParentId;


}
