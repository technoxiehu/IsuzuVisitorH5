package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 遗留，
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountAliasResp {

    private List<String> alias;

}
