package com.netease.qiye.qiyeopenplatform.common.dto.open.mailaccount;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.CommonUtils;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.HashMap;

/**
 * @description: desc
 * @author: ZhuXiaoShu
 * @date: 2021/9/18 18:52
 */
@Data
public class MailAccountResp {

    @ApiModelProperty(value = "域名")
    private String domain = null;// 域名

    @ApiModelProperty(value = "邮箱帐号名")
    @JsonAlias("account_name")
    private String accountName = null;// 帐号

    @ApiModelProperty(value = "收发信权限")
    @JsonAlias("rs_right")
    private int rsRight;//收发信权限

    @ApiModelProperty(value = "收发信权限")
    @JsonAlias("exp_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date expiredTime;//过期时间

    @ApiModelProperty(value = "是否有自动转发权限 0-否，1-是")
    @JsonAlias("fwd")
    private Integer enableFwd;

    public Integer getEnableFwd() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("fwd");
    }

    @ApiModelProperty(value = "自动转发是否需要手机验证 0-否，1-是")
    @JsonAlias("fwdmauth")
    private Integer fwdMAuth;

    public Integer getFwdMAuth() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("fwdmauth");
    }

    @ApiModelProperty(value = "是否禁止客户端pop删信,0:允许pop删信;1:禁止pop删信;-1:不修改")
    @JsonAlias("pop_delete")
    private Integer popDelete;

    public Integer getPopDelete() {
        if(CommonUtils.isStringEmpty(settings)){
            return null;
        }
        HashMap hashMap = CommonUtils.parseObject(settings, HashMap.class);
        return (Integer) hashMap.get("pop_delete");
    }

    @ApiModelProperty(hidden = true)
    private String settings;

}
