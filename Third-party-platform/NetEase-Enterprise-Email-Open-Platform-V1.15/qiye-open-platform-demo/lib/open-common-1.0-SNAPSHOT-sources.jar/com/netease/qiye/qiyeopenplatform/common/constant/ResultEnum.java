package com.netease.qiye.qiyeopenplatform.common.constant;

import lombok.Getter;

import java.util.Arrays;

/**
 * 业务异常枚举
 *
 * @author caixianyong
 * @createtime 2021/9/8
 */
@Getter
public enum ResultEnum {

    SUCCESS(0, "成功"),

    // 通用失败
    SYSTEM_ERROR(-1, "系统内部异常"),
    SYSTEM_INNER_SERVICE_ERROR(-2, "系统内部服务异常"),

    SYSTEM_COMMON_BIZ_FAILURE(-3, "通用业务操作失败"),

    SYSTEM_DATA_NOT_EXISTS(-4, "系统数据不存在"),

    //认证相关 -1xx
    AUTH_FAILURE(-100, "认证失败"),
    AUTH_DATA_NOT_FOUND(-101, "认证数据不存在"),

    //权限相关 -2xx
    ACCESS_DENY(-200, "访问受限"),
    IP_DENY(-201, "IP受限"),
    PERMISSION_NOT_REGISTER(-202, "接口权限未注册"),

    //TOKEN相关 -3xx
    TOKEN_NOT_AVAILABLE(-300, "token不可用"),
    TOKEN_ACCESS_EXPIRED(-301, "access token失效"),
    TOKEN_REFRESH_EXPIRED(-302, "refresh token失效"),
    TOKEN_GENERATE_ERROR(-303, "token产生失败"),
    AUTH_EXPIRED(-304, "授权失效"),
    APP_EXPIRED(-305, "应用失效"),


    TOKEN_SSO_GENREATE_ERROR(-320, "sso token 产生失败"),
    TOKEN_SSO_VERIFY_ERROR(-321, "sso token 验证失败"),
    TOKEN_SSO_EXPIRED(-322, "sso token 过期"),

    //请求错误相关 -4xx
    REQUEST_ERROR(-400, "请求异常"),
    PARAM_ERROR(-401, "请求参数异常"),
    REQUEST_REPEAT(-421, "请求重复"),
    REQUEST_FREQUENCY_TOO_HIGH(-422, "请求频率过高"),
    REQUEST_FREQUENCY_TOO_HIGH_APP(-423, "APP请求频率过高"),
    HEADER_ERROR(-424, "请求头异常"),

    //第三方服务异常 -5xx
    THIRD_ACCESS_ERROR(-500, "第三方服务访问异常"),

    ;


    private int code;
    private String description;

    private ResultEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static ResultEnum getByCode(int code) {
        return Arrays.stream(ResultEnum.values())
                .filter(re -> re.getCode() == code)
                .findFirst().orElse(ResultEnum.SYSTEM_ERROR);
    }


}
