package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class AccountUpdatePasswordReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "密码", required = true)
    @NotBlank(message = "密码 不能为空")
    private String password;

    @ApiModelProperty(value = "密码类型,密码是否md5编码过,0-明文，1-经过md5的hex编码")
    @ServletDispatcherFieldAlias("pass_type")
    private Integer passType = 0;

    @ApiModelProperty(value = "首次登录修改密码要求,0-不需要，1-web登录需要，客户端不需要，2-web登录需要且未改密码前客户端不能登录")
    @ServletDispatcherFieldAlias("passchange_req")
    private Integer passChangeFirstLogin = 1;

}
