package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AddressRevisionResp {

    @ApiModelProperty(value = "企业openID")
    @JsonAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "版本号")
    private Long revision;
}
