package com.netease.qiye.qiyeopenplatform.common.dto.open.push;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 新消息到达通知
 *
 * @author caixianyong
 * @createtime 2021/9/16
 */
@Data
public class PushMailSubscribeReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "邮箱账户名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "邮箱账户名 不能为空")
    private String accountName;

    @ApiModelProperty(value = "推送target，默认org_mail(企业回调)，详情咨询接口对接人员")
    private String target = "org_mail";

}
