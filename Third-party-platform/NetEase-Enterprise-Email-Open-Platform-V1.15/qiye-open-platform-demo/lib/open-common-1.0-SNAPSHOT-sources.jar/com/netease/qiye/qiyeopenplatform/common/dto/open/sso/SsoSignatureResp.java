package com.netease.qiye.qiyeopenplatform.common.dto.open.sso;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author caixianyong
 * @createtime 2021/11/30
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SsoSignatureResp {

    @ApiModelProperty(value = "用于单点登录的签名值")
    public String sign;

    @ApiModelProperty(value = "单点登录入口url")
    public String endpoint;

}
