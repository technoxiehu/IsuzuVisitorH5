package com.netease.qiye.qiyeopenplatform.common.dto.open.mobile;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class AuthInfo {

    @ApiModelProperty(value = "登录是否需要启动验证")
    @JsonAlias("login_auth")
    private Integer loginAuth;

    @ApiModelProperty(value = "转发配置是否需要启动验证")
    @JsonAlias("auto_forward_auth")
    private Integer autoForwardAuth;

    @ApiModelProperty(value = "数据恢复是否需要启动验证")
    @JsonAlias("mailrecovery_auth")
    private Integer mailRecoveryAuth;

}
