package com.netease.qiye.qiyeopenplatform.sdk.config.http;

import com.netease.qiye.qiyeopenplatform.sdk.util.SDKUtils;

import java.io.IOException;
import java.util.Map;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public class OkHttpClientImpl implements IHttpClient {

    @Override
    public String postJsonData(String url, Map<String, Object> params, Map<String, String> headersMap, boolean logEnable) throws IOException {
        return SDKUtils.sendPost(url, params, headersMap, null, true);
    }

}
