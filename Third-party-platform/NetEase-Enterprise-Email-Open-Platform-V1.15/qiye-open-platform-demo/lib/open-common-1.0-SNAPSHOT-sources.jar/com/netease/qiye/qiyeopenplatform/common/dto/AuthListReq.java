package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: 授权列表请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class AuthListReq extends BasePageReq {

    @ApiModelProperty(value = "应用ID")
    private String appId;
    @ApiModelProperty(value = "企业OpenID")
    private String orgOpenId;
    @ApiModelProperty(value = "状态 0正常 1冻结")
    private Integer status;
    @ApiModelProperty(value = "授权码")
    private String authCode;
}
