package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class DomainInfoItem {

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "域名id")
    @JsonAlias("domain_openid")
    private String domainOpenId;

    @ApiModelProperty(value = "是否具有查看企业通讯录权限")
    @JsonAlias("addr_right")
    private Integer enableAccessAddr;

    @ApiModelProperty(value = "是否企业通讯录中显示")
    @JsonAlias("addr_visible")
    private Integer visibleInAddr;

    @ApiModelProperty("是否别名")
    private Boolean alias;

    @ApiModelProperty(value = "创建时间")
    @JsonAlias("create_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date createTime;

    @ApiModelProperty(value = "是否已删除")
    private Boolean deleted;

}
