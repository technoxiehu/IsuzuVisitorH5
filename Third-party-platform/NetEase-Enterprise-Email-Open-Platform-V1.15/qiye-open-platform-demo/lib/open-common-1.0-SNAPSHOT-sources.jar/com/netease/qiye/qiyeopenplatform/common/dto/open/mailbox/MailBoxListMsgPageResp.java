package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailBoxListMsgPageResp {

    @ApiModelProperty("邮件总数量")
    private Long total;

    @ApiModelProperty("邮件数据")
    private List<MailInfoItem> var;

}
