package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressGroupDeleteReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true, value = "是否保留联系人,0-保留联系人，1-不保留联系人")
    @NotNull(message = "option 不能为空")
    private Integer option;

    @ApiModelProperty(value = "分组ID")
    @ServletDispatcherFieldAlias("group_id")
    private Long groupId;

}
