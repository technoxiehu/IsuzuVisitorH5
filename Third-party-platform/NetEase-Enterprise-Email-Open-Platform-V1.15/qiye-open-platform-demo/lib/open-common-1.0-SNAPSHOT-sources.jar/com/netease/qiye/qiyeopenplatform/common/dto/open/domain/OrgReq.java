package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class OrgReq implements OpenBaseReq {

    @NotBlank(message = "orgOpenId 不能为空")
    @ApiModelProperty(required = true, value = "企业OpenID,企业邮提供的企业对应OpenId")
    @ServletDispatcherFieldAlias("org_openid")
    private String orgOpenId;

    @NotNull(message = "是否显示别名域名 不能为空")
    @ApiModelProperty(value = "是否显示别名域名", required = true)
    @ServletDispatcherFieldAlias("alias")
    private Boolean showAliasDomain = false;
}
