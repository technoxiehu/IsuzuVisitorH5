package com.netease.qiye.qiyeopenplatform.sdk.service.pub;

import com.netease.qiye.qiyeopenplatform.common.dto.login.AppLoginReq;
import com.netease.qiye.qiyeopenplatform.common.dto.login.AppLoginResp;
import com.netease.qiye.qiyeopenplatform.common.dto.login.SsoLoginResp;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public interface IPubService {

    /**
     * 应用登录，获取对应Token
     */
    R<AppLoginResp> appLogin(String authCode);

    /**
     * 刷新token
     */
    R<AppLoginResp> refreshToken();

    /**
     * 获取单点登录授权token
     */
    R<SsoLoginResp> ssoAuthToken(String authCode);
}
