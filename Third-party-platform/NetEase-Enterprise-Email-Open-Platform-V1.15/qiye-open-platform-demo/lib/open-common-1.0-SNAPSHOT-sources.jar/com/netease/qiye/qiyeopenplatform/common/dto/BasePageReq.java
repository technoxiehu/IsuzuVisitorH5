package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;

/**
 * @description: 分页请求基类
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:15
 * @modifier: caixianyong
 * @modify-content: JSR303; pageable
 */
@Data
public class BasePageReq {

    @Min(value = 0, message = "分页页码不能为负数")
    @ApiModelProperty(value = "分页页码,默认查询首页，0")
    private int pageNum = 0;

    @Range(min = 1, max = 500, message = "分页大小不能为负数，亦不能超过500")
    @ApiModelProperty(value = "分页大小，默认50")
    private int pageSize = 50;
}
