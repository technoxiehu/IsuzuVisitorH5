package com.netease.qiye.qiyeopenplatform.sdk.service.pub;

import com.netease.qiye.qiyeopenplatform.common.dto.login.AppLoginResp;
import com.netease.qiye.qiyeopenplatform.common.dto.login.SsoLoginResp;
import com.netease.qiye.qiyeopenplatform.sdk.QiyeOpenPlatSDKConfig;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;
import com.netease.qiye.qiyeopenplatform.sdk.service.BaseService;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public class PubService extends BaseService implements IPubService {

    private QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig;

    @Override
    public QiyeOpenPlatSDKConfig getQiyeOpenPlatSDKConfig() {
        return this.qiyeOpenPlatSDKConfig;
    }

    public PubService(QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig) {
        this.qiyeOpenPlatSDKConfig = qiyeOpenPlatSDKConfig;
    }

    @Override
    public R<SsoLoginResp> ssoAuthToken(String authCode) {
        Q q = Q.init(null)
                .addParam("appId", qiyeOpenPlatSDKConfig.getAppId())
                .addParam("orgOpenId", qiyeOpenPlatSDKConfig.getOrgOpenId())
                .addParam("authCode", authCode);
        return this.requestSDK(q, "/api/pub/token/ssoAuthToken");
    }


    @Override
    public R<AppLoginResp> appLogin(String authCode) {
        Q q = Q.init(null)
                .addParam("appId", qiyeOpenPlatSDKConfig.getAppId())
                .addParam("orgOpenId", qiyeOpenPlatSDKConfig.getOrgOpenId())
                .addParam("authCode", authCode);
        return this.requestSDK(q, "/api/pub/token/acquireToken");
    }

    @Override
    public R<AppLoginResp> refreshToken() {
        String refreshToken = this.getQiyeOpenPlatSDKConfig().getRefreshToken();
        return this.requestSDK(Q.init(null), "/api/pub/token/refresh?refreshToken=" + refreshToken);
    }

}
