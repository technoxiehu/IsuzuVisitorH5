package com.netease.qiye.qiyeopenplatform.sdk.util;

import com.netease.qiye.qiyeopenplatform.sdk.config.json.IJson;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author caixianyong
 * @createtime 2021/9/2
 */
@Slf4j
public class CommonUtils {

    public static final Map<String, Map<String, Field>> CLASS_FIELD_MAP = new ConcurrentHashMap<>();

    private static IJson iJson;

    public static void setiQiyeOpenJson(IJson json) {
        iJson = json;
    }

    public static boolean isStringEmpty(String str) {
        return str == null || str.trim().length() == 0;
    }

    /**
     * 封装一下 方便以后更换json库
     *
     * @param text
     * @param clazz
     * @return
     */
    public static <T> T parseObject(String text, Class<T> clazz) {
        return iJson.parseObject(text, clazz);
    }

    public static <T> List<T> parseArray(String text, Class<T> clazz) {
        return iJson.parseList(text, clazz);
    }


    /**
     * 封装一下 方便以后更换json库
     *
     * @param object
     * @return
     */
    public static String toJSONString(Object object) {
        return iJson.toJsonString(object);
    }

    public static Map<String, Field> resolveAccessableFieldMap(Class<?> aClass) {
        return com.netease.qiye.qiyeopenplatform.common.util.CommonUtils.resolveAccessableFieldMap(aClass);
    }

    /**
     * 生成6位随机数验证码
     *
     * @return
     */
    public static String genValidCode() {
        String validCode = "";
        for (int i = 0; i < 6; i++) {
            validCode = validCode + (int) (Math.random() * 9);
        }
        return validCode;
    }

    public static Map<String, Object> beanToMap(Object obj) {
        return beanToMap(obj, 1);
    }

    public static Map<String, Object> beanToMapJson(Object obj) {
        HashMap hashMap = parseObject(toJSONString(obj), HashMap.class);
        return Objects.isNull(hashMap) ? Collections.emptyMap() : hashMap;
    }

    /**
     * Bean 转 Map
     *
     * @param obj
     * @param depth
     * @return
     */
    public static Map<String, Object> beanToMap(Object obj, int depth) {
        return com.netease.qiye.qiyeopenplatform.common.util.CommonUtils.beanToMap(obj, depth);
    }

    private CommonUtils() {
    }
}
