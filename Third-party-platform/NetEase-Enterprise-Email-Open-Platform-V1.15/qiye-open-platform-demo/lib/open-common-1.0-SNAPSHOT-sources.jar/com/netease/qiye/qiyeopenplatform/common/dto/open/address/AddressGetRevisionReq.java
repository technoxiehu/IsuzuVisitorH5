package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class AddressGetRevisionReq implements OpenBaseReq {

    @NotBlank(message = "orgOpenId 不能为空")
    @ApiModelProperty(required = true, value = "企业OpenId,企业邮提供的企业对应OpenId")
    @ServletDispatcherFieldAlias("org_openid")
    private String orgOpenId;

}
