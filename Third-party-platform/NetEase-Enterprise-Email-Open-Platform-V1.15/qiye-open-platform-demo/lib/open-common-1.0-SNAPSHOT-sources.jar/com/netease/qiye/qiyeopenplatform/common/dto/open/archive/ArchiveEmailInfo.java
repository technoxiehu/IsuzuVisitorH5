package com.netease.qiye.qiyeopenplatform.common.dto.open.archive;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class ArchiveEmailInfo {

    @ApiModelProperty(value = "归档邮箱账户")
    private String account;

    @ApiModelProperty(value = "归档时间Unix时间戳(毫秒)")
    private Long archTime;

    @ApiModelProperty(value = "归档域名")
    private String domain;

    @ApiModelProperty(value = "存储ID")
    private Long fid;

    @ApiModelProperty(value = "是否带附件")
    private Boolean hitAttach;

    @ApiModelProperty(value = "邮件ID")
    private Long mid;

    @ApiModelProperty(value = "公正邮状态(0全部，1未保全，2已保全，3已经申请，4不可保全)")
    @JsonAlias("notary_status")
    private Integer notaryStatus;

    @ApiModelProperty(value = "发信人信息")
    private String sender;

    @ApiModelProperty("邮件来源")
    private Integer source;

    @ApiModelProperty("邮件主题")
    @JsonAlias("topic")
    private String subject;

}
