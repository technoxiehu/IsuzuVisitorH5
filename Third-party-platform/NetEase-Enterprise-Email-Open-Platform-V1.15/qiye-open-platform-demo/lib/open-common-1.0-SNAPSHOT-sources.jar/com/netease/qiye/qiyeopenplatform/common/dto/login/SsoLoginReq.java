package com.netease.qiye.qiyeopenplatform.common.dto.login;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * 单点登录token
 * @author caixianyong
 * @createtime 2021/9/8
 */
@Data
@NoArgsConstructor
public class SsoLoginReq {

    @NotBlank(message = "appId 不能为空")
    @ApiModelProperty(value = "应用ID", required = true)
    private String appId;

    @NotBlank(message = "orgOpenId 不能为空")
    @ApiModelProperty(value = "企业OpenId", required = true, notes = "企业邮提供的企业对应OpenId")
    private String orgOpenId;

    @NotBlank(message = "authCode 不能为空")
    @ApiModelProperty(value = "授权码", required = true)
    private String authCode;

}
