package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class DomainReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;
}
