package com.netease.qiye.qiyeopenplatform.common.dto.open.pubaddress;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class PubAddressSortReq implements OpenBaseReq {

    @ApiModelProperty(value = "查询返回的addressId", required = true)
    @ServletDispatcherFieldAlias("address_id")
    private Long addressId;

    @ApiModelProperty(value = "域名", required = true)
    private String domain;

    @ApiModelProperty(value = "排序序号", required = true)
    @ServletDispatcherFieldAlias("sort")
    private Integer rank;

    @ApiModelProperty(value = "分组ID", required = true)
    @ServletDispatcherFieldAlias("group_id")
    private Long groupId;

}
