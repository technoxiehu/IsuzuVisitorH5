package com.netease.qiye.qiyeopenplatform.common.dto.open.unit;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @descriptions:
 * @date: 2021/9/15
 * @author: caixianyong
 */
@Data
public class UnitCreateReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名不能为空")
    private String domain;

    @ApiModelProperty(value = "部门名称", required = true)
    @ServletDispatcherFieldAlias("unit_name")
    @NotBlank(message = "部门名称不能为空")
    private String unitName;

    @ApiModelProperty(value = "部门描述")
    @ServletDispatcherFieldAlias("unit_desc")
    private String unitDesc;

    @ApiModelProperty(value = "上级部门的id,创建下级部门时使用，若作为顶级部门，则不传该参数")
    @ServletDispatcherFieldAlias("parent_id")
    private String parentId;


}
