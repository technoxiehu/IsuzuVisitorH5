package com.netease.qiye.qiyeopenplatform.common.dto.open.address;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AddressResp {

    @JsonAlias("unit_list")
    private List<AddressUnitItem> unitList;

    @JsonAlias("account_list")
    private List<AddressAccountItem> accountList;
}
