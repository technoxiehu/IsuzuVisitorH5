package com.netease.qiye.qiyeopenplatform.common.dto.open.mobile;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailMobileSmsResp {

    @ApiModelProperty(value = "随身邮号码")
    private String mobile;

    @ApiModelProperty(value = "随身邮激活状态描述,状态：0-不激活，1-激活 2关闭")
    @JsonAlias("status")
    private String statusDesc;

    @ApiModelProperty(value = "随身邮类型")
    @JsonAlias("type")
    private String typeDesc;//:类型：0-免费赠送，1-购买类型

    @ApiModelProperty(value = "随身邮月总量")
    @JsonAlias("month_max")
    private Integer monthMax;

    @ApiModelProperty(value = "随身邮月使用量")
    @JsonAlias("month_num")
    private Integer monthNum;

    @ApiModelProperty(value = "随身邮月剩余量")
    @JsonAlias("month_left")
    private Integer monthLeft;
}
