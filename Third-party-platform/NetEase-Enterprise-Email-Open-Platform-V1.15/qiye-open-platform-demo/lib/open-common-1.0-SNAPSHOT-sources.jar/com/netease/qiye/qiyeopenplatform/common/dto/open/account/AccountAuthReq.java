package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 指定账号的基础请求
 *
 * @author caixianyong
 * @createtime 2021/9/10
 * @see AccountAuthReq
 */
@Data
public class AccountAuthReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "是否开启客户端授权密码模式, 0-关闭，1-开启", required = true)
    @ServletDispatcherFieldAlias(value = "isEnable", expectedClass = Boolean.class)
    @NotNull(message = "是否开启客户端授权密码模式 不能为空")
    @Range(min = 0, max = 1, message = "该值仅支持 0 - 1")
    private Integer enableAuthCode;

}
