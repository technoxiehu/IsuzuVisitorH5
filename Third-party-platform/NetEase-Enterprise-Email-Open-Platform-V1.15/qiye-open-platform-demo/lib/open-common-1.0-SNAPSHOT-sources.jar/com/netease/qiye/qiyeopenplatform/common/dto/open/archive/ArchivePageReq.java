package com.netease.qiye.qiyeopenplatform.common.dto.open.archive;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class ArchivePageReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(value = "查询关键词")
    private String keyword;

    @ApiModelProperty(value = "查询范围类型,默认值是全部，多个类型用逗号分开\n" +
            "0-邮件正文\n" +
            "1-主题\n" +
            "2-附件标题\n" +
            "3-发件人\n" +
            "4-收件人")
    private String type = "0,1,2,3,4";

    @ApiModelProperty(value = "起始时间时间戳（毫秒）, 默认30天前")
    private long startTime = Date.from(LocalDateTime.now().minusDays(30)
            .atZone(ZoneId.systemDefault()).toInstant()).getTime();

    @ApiModelProperty(value = "结束时间时间戳（毫秒）")
    private long endTime = new Date().getTime();

    @ApiModelProperty(value = "分页数")
    @ServletDispatcherFieldAlias("page_num")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小,默认最大都为50")
    @ServletDispatcherFieldAlias("page_size")
    @Range(min = 1, max = 50, message = "分页大小 不能超过50，亦不小于1")
    private Integer pageSize = 50;

}
