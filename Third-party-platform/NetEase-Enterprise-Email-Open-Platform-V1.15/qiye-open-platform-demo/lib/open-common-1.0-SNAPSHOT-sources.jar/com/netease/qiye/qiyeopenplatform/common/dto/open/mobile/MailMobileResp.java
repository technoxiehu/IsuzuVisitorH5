package com.netease.qiye.qiyeopenplatform.common.dto.open.mobile;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailMobileResp {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀")
    @JsonAlias("account_name")
    private String accountName;

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "手机号码")
    private String mobile;

    private AuthInfo auth;
}
