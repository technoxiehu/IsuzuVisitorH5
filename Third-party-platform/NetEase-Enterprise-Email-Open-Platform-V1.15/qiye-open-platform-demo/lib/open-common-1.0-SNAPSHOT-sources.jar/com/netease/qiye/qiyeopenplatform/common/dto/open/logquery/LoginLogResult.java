/**
 * @(#)WebLoginLogEntity.java, 2015年6月1日.
 * <p>
 * Copyright 2015 Netease, Inc. All rights reserved.
 * NETEASE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.netease.qiye.qiyeopenplatform.common.dto.open.logquery;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * web登录日志查询结果
 *
 * @author machao
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginLogResult {

    private int total;

    private List<LoginLogQueryResp> list;

}
