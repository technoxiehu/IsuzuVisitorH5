package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * @description: 冻结/解冻应用授权请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/2 10:50
 */
@Data
public class AuthStatusReq {

    @ApiModelProperty(value = "授权ID", required = true)
    @NotNull(message = "授权ID 不能为空")
    private Long id;

    @ApiModelProperty(value = "状态 0正常 1冻结", required = true)
    @Range(min = 0, max = 1, message = "状态 0正常 1冻结")
    @NotNull(message = "状态 不能为空")
    private Integer status;

}
