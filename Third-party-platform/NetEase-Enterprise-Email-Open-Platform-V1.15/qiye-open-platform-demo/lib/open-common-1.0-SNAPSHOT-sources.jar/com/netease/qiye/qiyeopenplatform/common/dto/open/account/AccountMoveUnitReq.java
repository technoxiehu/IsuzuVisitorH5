package com.netease.qiye.qiyeopenplatform.common.dto.open.account;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/10
 */
@Data
public class AccountMoveUnitReq implements OpenBaseReq {

    @ApiModelProperty(value = "用户账号名，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "账号名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true,value = "所属部门id, 默认部门传\"default\",多个部门用英文半角逗号分隔")
    @ServletDispatcherFieldAlias("unit_id")
    @NotBlank(message = "所属部门id 不能为空")
    private String unitId = "default";

}
