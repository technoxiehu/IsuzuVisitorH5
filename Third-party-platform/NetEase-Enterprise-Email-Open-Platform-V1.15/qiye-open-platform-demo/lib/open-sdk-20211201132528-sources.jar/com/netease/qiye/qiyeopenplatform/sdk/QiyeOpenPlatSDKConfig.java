package com.netease.qiye.qiyeopenplatform.sdk;

import com.netease.qiye.qiyeopenplatform.common.dto.login.AppLoginResp;
import com.netease.qiye.qiyeopenplatform.sdk.callback.IHeaderCallback;
import com.netease.qiye.qiyeopenplatform.sdk.config.http.IHttpClient;
import com.netease.qiye.qiyeopenplatform.sdk.config.http.OkHttpClientImpl;
import com.netease.qiye.qiyeopenplatform.sdk.config.json.IJson;
import com.netease.qiye.qiyeopenplatform.sdk.config.json.JacksonImpl;
import com.netease.qiye.qiyeopenplatform.sdk.util.CommonUtils;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.Objects;

/**
 * SDK配置类
 *
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Getter
@Slf4j
public class QiyeOpenPlatSDKConfig {

    /**
     * 默认域名，也用于定位服务
     */
    private String domain;

    /**
     * 企业OpenId
     */
    private String orgOpenId;

    /**
     * 应用Id
     */
    private String appId;

    /**
     * 服务地址
     */
    @Setter
    private String urlPrefix;

    /**
     * 请求详细日志
     */
    private boolean logEnable = true;


    private String accessToken;
    private Date accessTokenExpiredEnd;
    private String refreshToken;
    private Date refreshTokenExpiredEnd;

    //可替换实现
    private IJson json;
    private IHttpClient httpClient;

    //全局header回调（适用添加固定header参数，全局签名参数）
    private IHeaderCallback headerCallback;

    @Builder
    public QiyeOpenPlatSDKConfig(String domain, String orgOpenId, String appId, String urlPrefix, boolean logEnable,
                                 IJson jsonImpl, IHttpClient httpClientImpl, IHeaderCallback headerCallbackImpl) {
        this.domain = domain;
        this.orgOpenId = orgOpenId;
        this.appId = appId;
        this.urlPrefix = urlPrefix;
        this.logEnable = logEnable;

        this.json = jsonImpl == null ? new JacksonImpl() : jsonImpl;
        CommonUtils.setiQiyeOpenJson(json);

        this.httpClient = httpClientImpl == null ? new OkHttpClientImpl() : httpClientImpl;

        this.headerCallback = headerCallbackImpl == null ? (p, h) -> h : headerCallbackImpl;
    }

    /**
     * 设置token
     *
     * @param appLoginResp
     */
    public void setupToken(AppLoginResp appLoginResp) {
        if (Objects.isNull(appLoginResp) || CommonUtils.isStringEmpty(appLoginResp.getAccessToken())) {
            throw new RuntimeException("无调用凭证，设置失败");
        }
        this.accessToken = appLoginResp.getAccessToken();
        this.refreshToken = appLoginResp.getRefreshToken();
        this.accessTokenExpiredEnd = appLoginResp.getAccessTokenExpiredTime();
        this.refreshTokenExpiredEnd = appLoginResp.getRefreshTokenExpiredTime();
        log.info("更新Token: accessToken:{}, refreshToken:{},access expired:{},refresh expired:{},",
                accessToken, refreshToken, accessTokenExpiredEnd, refreshTokenExpiredEnd);
    }

    /**
     * 测试用。。。通常在初始化阶段设置回调
     *
     * @param headerCallbackImpl
     */
    public void setupHeaderCallback(IHeaderCallback headerCallbackImpl) {
        if (Objects.isNull(headerCallbackImpl)) {
            throw new RuntimeException("header callback setup error");
        }
        this.headerCallback = headerCallbackImpl;
    }
}
