package com.netease.qiye.qiyeopenplatform.sdk.service.open;

import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountReq;
import com.netease.qiye.qiyeopenplatform.common.dto.open.account.AccountResp;
import com.netease.qiye.qiyeopenplatform.sdk.QiyeOpenPlatSDKConfig;
import com.netease.qiye.qiyeopenplatform.sdk.dto.Q;
import com.netease.qiye.qiyeopenplatform.sdk.dto.R;
import com.netease.qiye.qiyeopenplatform.sdk.service.BaseService;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
public class AccountService extends BaseService implements IAccountService {

    private QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig;

    @Override
    public QiyeOpenPlatSDKConfig getQiyeOpenPlatSDKConfig() {
        return this.qiyeOpenPlatSDKConfig;
    }

    public AccountService(QiyeOpenPlatSDKConfig qiyeOpenPlatSDKConfig) {
        this.qiyeOpenPlatSDKConfig = qiyeOpenPlatSDKConfig;
    }

    @Override
    public R<AccountResp> getAccount(Q<AccountReq> q) {
        return this.requestSDK(q, "/api/open/account/getAccount");
    }

}
