package com.netease.qiye.qiyeopenplatform.common.dto.open.autobackup;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/9/22
 */
@Data
public class AutoBackupItem {

    @ApiModelProperty(value = "备份账号")
    private String email;

    @ApiModelProperty(value = "被备份的账号")
    @JsonAlias("backup_email")
    private String backupEmail;

}
