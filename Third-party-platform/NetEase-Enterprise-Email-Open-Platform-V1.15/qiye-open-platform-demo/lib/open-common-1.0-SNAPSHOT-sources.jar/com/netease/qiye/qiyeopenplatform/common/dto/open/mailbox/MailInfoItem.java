package com.netease.qiye.qiyeopenplatform.common.dto.open.mailbox;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 结合 qiyeservice原先文档 以及 mailagent 实际响应结构（mailagent为主）
 *
 * @author caixianyong
 * @createtime 2021/9/24
 */
@Data
public class MailInfoItem {

    @ApiModelProperty(value = "文件夹ID")
    private Integer fid;

    @ApiModelProperty(value = "发送方")
    private String from;

    @ApiModelProperty(value = "邮件标识")
    private String id;

    @ApiModelProperty(value = "邮件标识:(无，即未读)/read/popRead/scheduleDelivery/attached/inlineAttached/linkAttached/signed/encrypted/replied" +
            "/forwarded/draft/voice/fax/flagged/deleted/top/rcptQueued/rcptFailed/rcptSucceed/deferHandle")
    private MailFlag flags;

    @ApiModelProperty(value = "优先级")
    private Integer priority;

    @ApiModelProperty(value = "送达时间")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date receivedDate;

    @ApiModelProperty(value = "发送时间")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date sentDate;

    @ApiModelProperty(value = "邮件大小")
    private Long size;

    @ApiModelProperty(value = "邮件主题")
    private String subject;

    @ApiModelProperty(value = "接收方")
    private String to;


}
