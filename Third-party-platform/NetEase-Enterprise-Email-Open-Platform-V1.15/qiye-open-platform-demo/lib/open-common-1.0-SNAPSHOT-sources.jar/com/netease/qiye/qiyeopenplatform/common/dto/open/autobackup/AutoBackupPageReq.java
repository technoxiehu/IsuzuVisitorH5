package com.netease.qiye.qiyeopenplatform.common.dto.open.autobackup;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class AutoBackupPageReq implements OpenBaseReq {

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名domain 不能为空")
    private String domain;

    @ApiModelProperty(value = "查询关键字")
    private String key;

    @ApiModelProperty(value = "关键字查询范围类型,0-按主备份邮箱,1-按被备份邮箱，默认为0")
    @Range(min = 0, max = 1, message = "关键字查询范围类型,目前仅支持 0，1")
    private Integer type = 0;

    @ApiModelProperty(value = "分页数")
    @ServletDispatcherFieldAlias("page_num")
    @Min(value = 1, message = "页数 不能小于1")
    private Integer pageNum = 1;

    @ApiModelProperty(value = "分页大小", notes = "默认最大都为50")
    @ServletDispatcherFieldAlias("page_size")
    @Range(min = 1, max = 50, message = "分页大小 不能超过50，亦不小于1")
    private Integer pageSize = 50;

}
