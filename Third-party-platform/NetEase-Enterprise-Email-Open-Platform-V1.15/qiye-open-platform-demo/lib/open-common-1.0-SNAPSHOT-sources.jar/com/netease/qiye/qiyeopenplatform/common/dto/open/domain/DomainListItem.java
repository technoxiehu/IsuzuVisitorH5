package com.netease.qiye.qiyeopenplatform.common.dto.open.domain;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.netease.qiye.qiyeopenplatform.common.util.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author caixianyong
 * @createtime 2021/9/13
 */
@Data
public class DomainListItem {

    @ApiModelProperty(value = "域名")
    private String domain;

    @ApiModelProperty(value = "企业openID")
    @JsonAlias("org_openid")
    private String orgOpenId;

    @ApiModelProperty(value = "企业组织数据的创建时间")
    @JsonAlias("create_time")
    @JsonFormat(timezone = "GMT+8", pattern = DateUtils.DATETIME_COMMON)
    private Date createTime;

    @ApiModelProperty(value = "是否赠送/初始域; 0非1是")
    @JsonAlias("orginal_domain")
    private Integer originalDomain;

    @ApiModelProperty(value = "域名所有权验证状态，0--待校验，1-校验通过，2-校验失败")
    @JsonAlias("spf_status")
    private Integer spfStatus;

    @ApiModelProperty(value = "0-新增域名/域别名,1-修改域名/域别名")
    @JsonAlias("reg_type")
    private Integer regType;

    @ApiModelProperty(value = "域名修改时，所关联的旧域名")
    @JsonAlias("old_domain")
    private String old_domain;

    @ApiModelProperty(value = "0:域名新增/修改进行中。1:域名新增/修改成功。")
    private Integer status;



}
