package com.netease.qiye.qiyeopenplatform.sdk.dto;

import com.netease.qiye.qiyeopenplatform.sdk.util.CommonUtils;
import lombok.Data;

/**
 * @author caixianyong
 * @createtime 2021/10/20
 */
@Data
public class R<T> {

    private Integer code;
    private String message;
    private Boolean success;

    //序列化结果
    private T data;

    private String responseText;

    public T getDataBean(Class c) {
        return (T) CommonUtils.parseObject(CommonUtils.toJSONString(this.getData()), c);
    }
}
