package com.netease.qiye.qiyeopenplatform.common.dto.open.maillist;

import com.netease.qiye.qiyeopenplatform.common.annotation.ServletDispatcherFieldAlias;
import com.netease.qiye.qiyeopenplatform.common.dto.open.OpenBaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author caixianyong
 * @createtime 2021/9/14
 */
@Data
public class MailListMemberReq implements OpenBaseReq {

    @ApiModelProperty(value = "邮件列表名称，邮箱格式的前缀", required = true)
    @ServletDispatcherFieldAlias("account_name")
    @NotBlank(message = "邮件列表名称 不能为空")
    private String accountName;

    @ApiModelProperty(value = "域名", required = true)
    @NotBlank(message = "域名 不能为空")
    private String domain;

    @ApiModelProperty(required = true, value = "需要增删的邮件列表成员（邮箱）,用英文逗号 , 隔开的邮件地址列表 例如\n" +
            "test1@test.com,test2@test.com")
    @ServletDispatcherFieldAlias("forwardlist")
    @NotBlank(message = "需要增删的邮件列表成员（邮箱） 不能为空")
    private String members;


}
