package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: token列表请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/3 10:47
 */
@Data
public class TokenListReq extends BasePageReq {

    @ApiModelProperty(value = "应用ID")
    private String appId;
    @ApiModelProperty(value = "企业OpenID")
    private String orgOpenId;
    @ApiModelProperty(value = "状态 0正常 1冻结")
    private Integer status;
}
