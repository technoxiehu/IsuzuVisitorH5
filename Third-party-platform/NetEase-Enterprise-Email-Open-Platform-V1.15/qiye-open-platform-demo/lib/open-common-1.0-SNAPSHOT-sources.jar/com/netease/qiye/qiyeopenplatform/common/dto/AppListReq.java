package com.netease.qiye.qiyeopenplatform.common.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: 应用列表请求
 * @author: ZhuXiaoShu
 * @date: 2021/9/9 15:31
 */
@Data
public class AppListReq extends BasePageReq {

    @ApiModelProperty(value = "主键ID")
    private Long id;
    @ApiModelProperty(value = "应用ID")
    private String appId;
    @ApiModelProperty(value = "应用名称")
    private String appName;
    @ApiModelProperty(value = "状态 0正常 1冻结")
    private Integer status;
}
